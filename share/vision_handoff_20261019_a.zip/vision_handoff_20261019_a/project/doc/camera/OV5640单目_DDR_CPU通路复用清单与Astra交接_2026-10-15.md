# OV5640单目 → DDR → CPU读取：复用清单与Astra交接

2026-10-15。工程根`D:/riscv/RISCV`。用户已明确暂停CPU性能提升，当前目标为**单目OV5640采集后写DDR，再由真实CPU读取**；不做双目拼接、HDMI显示或图像算法。Astra负责后续RTL，本对话Sol负责测试方案/测试代码与原始证据，DeepSeek仅执行，用户PDS/下载/KEY0/实板。

本次只读分析，分支master原有RTL/PDS/IP修改均保持；未复制设计到myriscv、未修改RTL/PDS/IP/成功镜像，未运行仿真/PDS/串口/KEY0。032成功P/V2.242630368/2.240607786667s与全部旧证据保留，性能优化暂不推进。清单中的“复用”不是demo功能/新集成PASS。

## 当前进度：单缓冲100帧正常循环实板复核通过，保留两帧导图成功基线

用户回传`sim/camera/board/loop100_20261015_01/`，Sol完整离线复核实际89应答Loader/唯一RUN/单G/ID及配置、100帧原始摘要、结束统计及CSV，并核固定BIN/源文件/工具与受保护设计、旧成功固件身份。序号1→100，采集CRC与CPU全帧CRC100/100匹配，STATUS全5、ERROR全0，SUCCESS=100，无重试；固定固件逐帧检查BUSY→DONE、921600像素/1843200字节/57600拍及读取前后元数据稳定。累计CPU整帧读取184320000字节。原报告/字节/CSV不改，新增[Sol收据](../../sim/camera/board/loop100_20261015_01/sol_review.json)SHA43a0eeff10170ce3e44d4801dabadee11e4661645b540f403da35fd0c06ae0d2，**CAMERA_LOOP100_BOARD_DATA_ACCEPTANCE_PASS**。复现复核命令`python tools/camera_uart/loop100.py --verify sim/camera/board/loop100_20261015_01`，只读不打开串口。

总耗时114.613935328秒；等待70.220193493秒(61.267%)，CPU读取加CRC43.284508704秒(37.765%)，其余1.109233131秒(0.968%)。等待均值702.201935ms，首帧749.464949ms，后99帧701.708843–701.805845ms/均值701.724531ms；CPU均值432.845087ms、范围432.843659–432.854069ms，跨度10.411μs。没有随轮次变慢或超时。等待含每次ARM丢10个启动帧，是当前最大阶段；CPU读取/CRC占比也高，但日志不能把计算/访存再拆开归因到DDR。

100个CRC均不同（595dd45e→b6fd87cf），变化仅记录；静止场景相同CRC仍合法，不单凭CRC判断旧帧或主动改画面动作。本次日志未单独确认用户中途改画面。约0.8725已校验帧/s是串行ARM/等待/CRC/打印流程完成率，不是传感器帧率；约4.258MB/s是CPU读取加CRC有效速度，不是独立DDR带宽。当前正常循环数据验收完成，无新RTL缺陷证据，不改RTL、不重PDS、不重复长SoC/历史全套。无本轮图像导出/PC帧CRC/新看图结论，沿用两帧成功；原长SoC超时仍未完成，错误注入范围沿既有证据，不写100帧已穷尽错误路径。此次只分析用户日志，不运行硬件或新测试。

## 前次进度：两帧实板成功保留，软件100帧循环准备完成

用户新要求沿用成功RTL/位流和全部采集参数，仅用软件在单缓冲上连续100次ARM/等完成/元数据与CPU全帧CRC检查，不逐帧导图、不自动重试，用户中途改变画面；相同CRC合法，不作旧帧判据。Sol新增`tests/camera_loop100/`和`tools/camera_uart/loop100.py`，逐帧强制BUSY/DONE过程及序号递增、精确元数据/无错、读前后稳定，失败立即停并保存诊断，结束统计成功数及采集等待/CPU校验总计/最小/最大/均值。计时93750000Hz，WAIT含10个丢弃帧，软件扩展64位跨CYCLE回绕。CPU读取每1024字采样并执行20秒超时，采集软件5秒/RTL原3秒超时保持，不自动ABORT清状态或降低判据。

固定BIN10896字节，SHA82f6698dfeb820219a698b5d752c9c0d033e734ecde52c99b33ad805ad3c7cc6，Loader CRC7c9c3d04；静态2187指令/ELF/BIN/栈检查过，native实际C模拟MMIO14例、独立图案zlib CRC及46080000逐字读取、CRC重复合法/计时和序号回绕，错误首败不再ARM均过；串口/原始字节/统计8例及错误拒收过。只属于软件native/OFFLINE证据，无新真实CPU HDL或100帧实板PASS。207项RTL/IP/PDS和原两帧成功BIN/日志保持，详见[交接收据](../../sim/camera/loop100_preparation_20261015_a/handoff_review.json)。

使用当前成功位流、无需PDS，根目录执行`python tools/camera_uart/loop100.py --port COM9 --log-dir sim/camera/board/loop100_20261015_01`，按提示KEY0，运行中改变画面。89个Loader应答/VERIFY/唯一RUN后单G启动连续100帧，每帧只摘要，完整RX/TX/CSV/result/verified保留；[操作说明](../../tests/camera_loop100/README.md)。日志新目录当前未创建，用户实板待执行；若失败先由Sol核原证据，证实RTL才给Astra最小复现，不续长SoC/历史全套。

## 成功基线：两帧串口采集、CPU/PC全帧CRC及用户看图实板验收通过

用户回传`sim/camera/board/uart_frames_20261015_01/`，并确认“日志已写回,图片正确”。Sol执行`python tools/camera_uart/capture.py --verify sim/camera/board/uart_frames_20261015_01`，完整重放原始Loader和收发字节、逐包CRC/序号/偏移/ACK、原始帧CRC与RGB565小端行优先PNG映射；结果与原verified.json一致，已查看两张PNG。新增[Sol复核收据](../../sim/camera/board/uart_frames_20261015_01/sol_review.json)，SHA4aac1ccd43974c57d2dad71e71d76099120898becf5ee61a565b4a04804c8088，正式结论 **CAMERA_UART_TWO_FRAME_BOARD_ACCEPTANCE_PASS**，保留原自动报告VISUAL_PENDING，人工确认单独登记，不回填改写原记录。

实际传感器ID5640/配置OK；两次ARM序号1→2；每帧921600像素、1843200字节、57600写拍，OVERFLOW=0/ERROR=0，采集CRC/CPU首读整帧CRC/CPU复读整帧CRC/PC导出CRC四者一致，分别31167575、3F8A68B9；每帧1800个1024字节块及结束包完整，图片正确且场景变化。53个Loader应答和唯一RUN、结束CAPTURES=2/EXPORTS=2通过，实际RX3805334/TX10827字节。固定6212字节BIN SHA373940da…f529和构建/工具源身份保持，不重新构建、不改RTL/PDS/IP/成功镜像。

当前单目相机→DDR→CPU→串口→PC图像验收目标完成；缓存隔离/重复ARM在本次两帧整帧读取范围通过，最终W与DONE顺序沿用下述独立仿真原证据，不把串口当周期轨迹。原7200秒SoC超时记录继续保持未完成，不追写全仿真PASS；本次未运行串口/仿真/PDS，只复核用户实板证据。无需继续长仿真或重复上板；无新异常/修改不补历史全套，CPU性能优化仍暂停。

## 前次进度：超时前缀已核，完整SoC长仿真停止续跑，转串口实板采帧

用户提出Astra的“相机ID/配置＋单帧元数据＋两次CPU CRC＋串口二进制导出＋PC CRC/PNG＋改画面再ARM”方案。Sol已核当前长仿真原证据，决定不再续跑/扩大7200秒的完整720p CPU仿真预算，沿已核SCCB/faults和本轮有效前缀推进用户实际DDR采帧；原失败结论与未覆盖范围保留。

`ds_camera_soc_bootmap_20261015_a`在7200.4879822秒被超时杀掉（native1/timeout=true），没有新功能失败标记，不是SCCB卡死。stdout最后停在首次ID读取是缓冲尾部，不是实时进度。独立[完整记录前缀复核](../../sim/camera/key/review_timeout_20261015_a/review.json)证明：317项三处输入、厂商/工具/INI/Git/原证据保持；前16退休确为预期DDR程序；两套921600像素DVP驱动、两帧各57600次实际W的全部地址/字节/byte-enable正确；硬件CRC分别AD4E00C3/68C5601B，DONE均在最后W之后2周期。第一帧CPU460800字及复读完整，已上报AD4E00C3；第二帧CPU已核73042字，原生AR/R仅完整保留73013字前缀；两个日志硬杀后独立缓冲，尾部各有半行，不能补齐或强写跨文件守恒。302955次实际CPU非帧DDR写已比对。**缺第二CPU全帧CRC/最终覆盖/完成标记，仍不是整组SoC PASS。** 不修改旧result.json或失败目录，不把它交Astra当已证实RTL反例。

已实现固定[CPU串口验收程序](../../tests/camera_uart/README.md)和[PC工具](../../tools/camera_uart/README.md)。固定BIN6212字节，SHA373940da…f529，Loader整镜像CRC26abe2d1；构建入口/ELF/BIN/DAT/manifest在`tests/camera_uart/`，PC脚本在`tools/camera_uart/`。程序只从现有Loader装入0x40000000，不替换ROM/RAM/DAT或成功CoreMark/Loader，不改RTL/PDS/IP。实际SENSOR_ID=5640、配置无错、帧计数/写拍/序号、两次CPU整帧CRC均须正确；二进制1024字节分块、独立Header/Data CRC和ACK，PC按固定RGB565小端行优先生成PNG，记录全体原始RX/TX并离线复核。两帧间用户明显改画面后再次ARM，要求CRC变化。真实图像CRC没有仿真中的固定数值。

RV32I构建及1151条指令合法性、镜像/段/栈审计通过；native直接调用同一C CRC代码验证两套整帧、C/Python包头一致；合成两帧收发与坏Header/数据/序号/偏移/不变场景/篡改RX/短读拒收已核。所有离线证据标OFFLINE_SYNTHETIC_TEST，CLI实际日志验证拒绝此类证据；详见[软件交接收据](../../sim/camera/uart_preparation_20261015_a/handoff_review.json)。新BIN仅静态/native/协议验证，**没有新Full Boot或新固件CPU仿真PASS，也没有实板PASS**；本次按用户提出的串口流程，剩余验证改由用户真实DDR/相机执行，保留这一风险/范围。

使用已通过时序的Camera位流，用户执行`python tools/camera_uart/capture.py --port COM9 --log-dir sim/camera/board/uart_frames_20261015_01`。工具提示KEY0释放/DDR就绪，复用53个Loader应答和唯一RUN，下载固定同一BIN，不自动重建、不启动PDS。默认两帧各导图，1024字节块加包头理论约165秒/帧，USB/ACK还会增加。首帧完成后提示用户改画面；每帧保存RGB565、PNG，最终原始字节/CRC/图像映射独立复核，颜色/行序/画面仍待用户人工确认。日常可`--summary-only --captures 1`省去导图，但该结果不含PC帧CRC。

当前仅串口程序与PC工具准备完成，待用户实际运行/看图并交原目录。旧SoC续测任务停止领取，不要求重做PDS或重跑SCCB/faults/CoreMark/ISA/PHY；Sol未打开串口/下载/KEY0/实板、不自动消息。记录仍在同一相机阶段，不另起重复测试归档。

## 前次准备：SCCB/faults已核通过，SoC测试启动映射修复

Sol已复核`ds_camera_ini_resume_20261015_a`完整原始输入、native命令/日志/独立checker及Git：[收据](../../sim/camera/key/review_soc_bootmap_20261015_a/review.json)为CAMERA_SCCB_FAULTS_RAW_REVIEW_PASS_SOC_BLOCKED_BY_TEST_BOOT_MAP。271项活动/封存/运行身份、3厂家/4工具/INI/5include/55模块及Git前后一致。SCCB7例正常244写/8读和4位置NACK、ID/格式错误全部通过；faults8例及独立字节/地址前缀核对通过，实际DMA写拍数为1024、1023、1、1、1、0、0、0，最后两复位及永久阻塞不假DONE。额外独立重放原始仲裁12次AW/30次W，CPU6×4拍/相机6×1拍的owner、地址、数据和strobe正确。小帧故障/仲裁范围内功能通过，不等于完整720p真实CPU验收；两组复用，不重跑。

SoC在3290461ps（3.290461us）触发CPU trap；native0但有Fatal/Errors1，原runner正确首败停止。原bus/cpu/dvp文件均0字节，没有ARM、图案采集或全帧CRC记录。trap PC/cause/tval原TB未打印，无法从原记录恢复，不能补猜具体指令。已确认的测试错误是设置soc_ddr3_top.RESET_PC=40000000后，子soc_top的INST_ROM_BASE/DATA_RAM_BASE因默认跟随RESET_PC也为40000000，入口优先ROM而非预装DDR；预期CRC表0x1000也不在该RAM窗口。先修明确的测试参数缺陷，尚无针对预期测试软件的RTL最小反例，不交Astra猜修RTL。

原tb_soc.sv/所有旧清单、封存和两个失败目录完整保留。新增`tb_soc_bootmap.sv`：显式defparam子soc_top两片内基址为0、PC仍40000000，补启动/入口路由、第一退休PC/指令、表写RAM的检查与最初16条退休和trap PC/inst/cause/tval/target诊断。真实设计/CPU/FIFO/缓存、模型、941条软件指令、图案/参考/独立checker、所有全帧与缓存/ARM/DONE判据/超时均保持。ModelSim完整静态编译55模块0错0警告；Icarus仅编译出未执行的部分展开产物，旧基址40000000/新基址0、PC不变已从参数记录逐项确认，未run vvp或vsim功能仿真。[静态收据与TB差异](../../sim/camera/key/preparation_soc_bootmap_20261015_a/static_review.json)在同目录可复现。

仅执行[SoC启动映射修复任务](../../DeepSeek/相机首版_SoC启动映射修复_仅SoC续测_2026-10-15.md)：`python sim/camera/key/run_soc_bootmap.py --check-inputs`再`python sim/camera/key/run_soc_bootmap.py`。新`inputs_soc_bootmap.json` SHA **44437cb7042b70b7430336105696b7aacc84863cc51c0d2629afca12af33eecb**，317项工程/参考/原证据，封存`sealed_soc_bootmap_20261015_a/`；正式目录`build/ds_camera_soc_bootmap_20261015_a/`尚未创建，预检查和plan-only通过。49源55模块5include，GRS/初始化参数仍闭合。新组只有vlib/compile/soc/soc_check，复用已核SCCB/faults，不跑CoreMark/ISA/PHY；首败停止并保留，看到trap交完整新诊断给Sol。

RTL/PDS/IP/成功镜像未改，不要求用户重做PDS，不启动PDS/实板或自动发消息。当前SoC全帧校验及实板未验收，复核新SoC原始证据后才继续实板准备。原faults35条未接端口提示（vsim3017×2/3722×33）保持，Errors0；SoC28条同类提示及IPSpec输出也保持，不把它们改写为零warning或新PASS。

## 前次首败：INI启动参数问题，Sol复核并封存只改入口的续测

2026-10-15已查看DeepSeek首轮`sim/camera/key/build/ds_camera_key_20261015_a/`。Sol按原始副本/清单/原生命令/log/transcript与git复核：[review.json](../../sim/camera/key/review_first_failure_20261015_a/review.json) SHA **dc045315eedcb56592c8c6c795ff863cc88ac0bf160babd9265e0a159f702f45**，输入246项在活动/原封存/运行副本全部一致，3厂家/4工具/INI/5include一致，git前后相同，原证据哈希通过。vlib与55模块编译native0/0错0警告；sccb启动native12、3.2414095秒、未超时，`vsim-7`报绝对`-modelsimini`文件参数带花括号而EINVAL，随后Error loading design、Errors2/Warnings0。未进入DUT或run-all，无SCCB功能案例，faults和SoC未启动。不能记为RTL功能失败，更不能写功能PASS。

最小修复属于Sol执行脚本：新增`run_ini_resume.py`，复用原run.py且只将三个vsim job的`-modelsimini`值改为私有cwd内`modelsim.ini`；原设计/TB/模型/程序/参考/检查器/判据/超时不变，原run.py与A全部246项仍保持原哈希。Sol以相同INI、无设计名、无run命令的启动探测确认native0/Errors0/Warnings0，原始探测argv/stdout在同review目录；此检查不是HDL或设计载入PASS。

当前唯一[修复续测任务](../../DeepSeek/相机首版_INI启动参数修复续测_2026-10-15.md)，命令为`python sim/camera/key/run_ini_resume.py --check-inputs`再`python sim/camera/key/run_ini_resume.py`。新清单`inputs_ini_resume.json` SHA **0cadecef11c33d41d52b233a9aa629a51791843756f235c829c3fa32c08ce3f7**，271项工程/参考/原A证据，封存`sealed_ini_resume_20261015_a/`；原49编译源/55模块/5include/3厂家和全部功能判据保持。新目录`build/ds_camera_ini_resume_20261015_a/`尚未创建，check-inputs/plan-only通过；在此执行此前尚未执行的SCCB→faults→真实CPU两帧组一次，不复跑任何历史功能基线。

原A首败/清单/封存/任务/输入全部保留，不删除、不修改、不续写、不从旧目录重试。DeepSeek仅执行新入口，首败停交Sol；没有真实功能失败证据可交Astra，RTL不改，不重做PDS。当前功能/实板仍未验收；本次未运行DUT/PDS/串口/KEY0、不自动消息。下方准备段的旧run.py命令仅为历史入口。

## 前次准备：用户确认新版PDS时序通过，Sol封存关键测试

2026-10-15本轮用户明确确认新版PDS时序通过；Sol接手后读AGENTS/HANDOFF/本阶段与相关RTL，核工作树及修复清单五项after身份，未重审PDS或推测WNS，未改设计/PDS/IP/成功镜像。直接分工为Sol编写TB、模型、真实CPU程序、独立参考/检查器、封存/执行脚本，DeepSeek仅执行；此前“等PDS/无任务”为历史。

[唯一执行任务](../../DeepSeek/相机首版_精简关键测试_2026-10-15.md)与[测试目录](../../sim/camera/key/README.md)已就绪。目标是一次精简关键组，不跑CoreMark/ISA/DDR PHY：

- SCCB正常244项写/8项读回、四个字节NACK位置、ID与格式读回错误；开漏从引脚解码，不窥探DUT序号应答。
- 128×128真实FIFO自然溢出、短帧、busy重复ARM、AW/W两阶段ABORT与复位、永久背压不假完成；最后W延迟，检查DONE/元数据。独立原生仲裁含6个CPU四拍burst+6个相机单拍，覆盖同时竞争、同拍AW/W、分离W和背压；9个边界译码检查帧区禁止取指/busy访问隔离。
- 真实soc_ddr3_top→soc_top→mycpu_sync和原Cache/FIFO/仲裁，两次完整1280×720 RGB565采集至同一帧区；全部921600个32位load做CPU查表CRC，另6个帧首预读验证no-hit/no-fill和重复ARM新鲜度。不force Cache、不flush、不缩小正常帧/只抽首尾。独立图案CRC为AD4E00C3、68C5601B。

独立Python参考从输入图案生成字节，SV刺激另行实现相同数学定义并保存全部实际驱动DVP像素；checker逐像素核输入、逐拍核115200次实际相机W的地址/字节使能/数据、逐字核CPU真实读值与对应原生AR/R。DONE须晚于扣住的最后W实际消费，FRAME_BYTES/PIXELS/SEQ/CRC原子一致，CPU计算值既比寄存器CRC也比独立常量。相机采集中CPU持续写非帧DDR地址，触发真实posted AW/W竞争，不用合成请求代替此项。

`sim/camera/key/inputs.json`绑定封存副本`sealed_20261015_a/`和唯一新运行目录`build/ds_camera_key_20261015_a/`。49编译源+递归include（csr_defs.vh、ROM/RAM两个初始化参数、测试DDR头文件），3厂家原语、三个顶层GRS、工具与私有modelsim.ini全部封存；执行时从封存集合再复制运行输入并闭合核对，首败保留、不改旧失败或历史基线。命令：

```powershell
Set-Location 'D:\riscv\RISCV'
python sim/camera/key/run.py --check-inputs
python sim/camera/key/run.py
```

Sol静态验证原始记录在`sim/camera/key/preparation_20261015_a/`：最终ModelSim vlog完整编译native0/Errors0/Warnings0；Icarus null部分展开native0（IP未展开，不把它写成完整IP验收）；实际编码的CPU CRC核对两图案各1/17/256字离线样本与zlib一致。941条指令的cpu.S/cpu.dat为测试DDR预装入口，CRC表由真实CPU写RAM0x1000；并未改两片内IP初始化或Loader成功DAT。只有ddr3控制器/PHY用原生用户口模型替换，配置子模块CLK_HZ缩为1600000加速计数，core/PCLK、正常帧尺寸、FIFO与DMA保持。此项不证明真实传感器上电/SCCB电气、Loader Full Boot、DDR PHY或实板。

最终[清单](../../sim/camera/key/inputs.json)SHA **859fca5ca0e87c77976b3d3fbe3d80d408c37bb8e62ad9e720ca1d549e3064d3**，246个工程/参考/历史证据文件、3厂家原语、4工具及私有INI；49源编译55模块。递归include/封存SHA/GRS预检查和plan-only均通过，正式运行目录尚未创建。详见[静态收据](../../sim/camera/key/preparation_20261015_a/static_review.json)及同目录完整命令/日志。最初Icarus全IP尝试的方言不兼容日志保留；最终完整编译依据是ModelSim而非该失败日志。封存也曾在写副本前因误套历史032桥SHA停止，已把旧原始证据与当前相机设计身份分开核对，未运行仿真或覆盖旧证据。

**当前仅测试准备封存完成，功能仿真未执行。** DeepSeek只执行已封存入口并返回完整目录；Sol核原证据后再给用户实板准备。若RTL缺陷，保留首败并整理最小场景、外部输入/握手/元数据时间线交Astra；本轮不自动向别的对话发消息。032成功基线原证据保持且不继承为本版PASS。

## 历史：首版RTL接入及PDS时序修复

### 首轮PDS时序违例修复（14:27报告）

用户提供本轮`report_timing/board_top.rtr`。核心慢角setup WNS−0.797ns、TNS−73.111ns、228个失败端点；相机setup−0.029ns、TNS−0.050ns、2端点；core→PCLK复位recovery慢角−4.568ns、快角−3.573ns，各2端点。报告列出的核心最差3条路径均为D缓存DRM→数据响应MUX→load结果/前递→ID分支判断→指令ROM地址；相机两条为camera_data[1]→CRC[22]/[20]。当前跨域数据最大延时汇总为正，不能将复位recovery误判为Gray数据路径失败；hold/removal摘要未见负裕量。

本轮修改：

1. `soc_top.v`在ENABLE_CAMERA分支中，桥DDR数据响应的valid/data/error一起寄存后交数据互连，增加一拍；请求所有权仍由原互连保持到该响应，bridge不需要response-ready。复位取消寄存valid，错误与数据始终随valid同行；I请求/返回不改。ENABLE_CAMERA=0保留原直接响应，CPU核/DDR桥/IP没有本轮修改。此举针对现有组合长链，不是继续CoreMark性能优化，也不保证所有228端点已闭合，须新PDS结果判断。
2. `ov5640_capture.v`把DVP 8bit、HREF、VSYNC一起输入寄存，字节相位、边界检测、FIFO写和CRC全部消费同一拍的信号。输入到CRC的外部半周期组合链切断，CRC运算获得完整PCLK周期；帧边界与数据同延一拍，最后像素先累计再发布帧完成的逻辑保持。没有放宽DVP输入预算或改CRC算法。
3. `camera_mmio.v`保留wr_reset_pipe/rd_reset_pipe两级释放并加syn_preserve。综合网表确认wr_reset_pipe[0:1]是GTP_DFF_C，C为异步清零，设备映射后为报告RS。有效FDC与参考FDC增加`set_false_path -to [get_pins {u_soc.g_camera.u_camera.wr_reset_pipe*/C}]`，仅豁免复位同步器自身无法与异域源保持相位关系的异步脚；不豁免D/CLK、级间数据或同步释放后的下游复位。PDS需确认该选择器只匹配两个C脚，未匹配不能忽略，不用整域false path代替。

[原始报告/前像](../../sim/camera/timing_fix_20261015_a/before.json)与[修复身份/详细路径](../../sim/camera/timing_fix_20261015_a/repair_review.json)已保存。验证仅Icarus `-g2005 -tnull -i -I myriscv`静态部分展开：board_top启用相机、soc_top以ENABLE_DDR=1/DDR_MEM_DQ_WIDTH=32/ENABLE_CAMERA=0两组退出0；启用组保留缺省DDR黑盒导致的两个时钟方向警告。没有执行vvp/vsim/PDS或实板，不记新PASS。复现命令/输出见该目录syntax_camera.log、syntax_camera_disabled.log及本段参数说明，厂家IP黑盒仍未完整展开。

现在必须由用户**重新综合→映射→布局布线→时序报告**，因RTL已变更不能仅复用旧网表重报。原失败报告代表修复前版本；新时序未返回，继续等待，不派发功能仿真或上板。Sol后续关键测试需覆盖响应新增一拍下的load/分支/连续请求及复位取消，并覆盖DVP输入寄存后的最后像素/边界/CRC；不追加历史全套。

### 后续用户指定FDC检查：引脚匹配，相机时序入口缺失

**FIFO端点后续修复：** 用户PDS在847/848行报空from_list。核`synthesize/run.log`及现存08:57综合网表`synthesize/bak/board_top_syn.vm`，实际寄存器为控制器下的`ASYN_CTRL.wptr[12:0]`、`ASYN_CTRL.rwptr1[12:0]`、`ASYN_CTRL.rptr[8:0]`、`ASYN_CTRL.wrptr1[8:0]`；此前约束漏写ASYN_CTRL。已给四个端点补齐该层级，保持10ns最大数据路径限制，并同步参考FDC/生成脚本。[证据记录](../../sim/camera/static_20261015/fdc_fifo_hierarchy_fix.json)绑定原错误、网表SHA和修复前后FDC SHA。没有运行新PDS或改RTL，等待用户重新加载约束后确认实际匹配；静态名称核对不等于PDS导入/时序通过。

**随后用户要求“添加约束”，该缺项已修复。** 相机时序13条命令（1 clock、2 input delay、10 max delay）已追加到当前唯一被PDS引用的`constraint_check/temp_constraint_file.fdc`第839–855行，原48982字节保持不变；未重新引用camera_single.fdc，未重复追加引脚。核对每条命令恰好一次及`git diff --check -- constraint_check/temp_constraint_file.fdc`通过。[合并记录](../../sim/camera/static_20261015/fdc_timing_merge.json)记录前SHA72103e5c…4585、后SHAc9e2d110…7a0c及未运行PDS/仿真事实。下一步由用户重新加载FDC实现，核对端点匹配和时序；此修复不证明预算或CDC物理实现已通过。以下保留检查时的原始发现。

2026-10-15只读检查用户指定的`constraint_check/temp_constraint_file.fdc`及当前RISCV.pds：该FDC共837行，相对HEAD仅在原761行后追加76行相机IO属性，原DDR/KEY0/UART/LED约束前缀保持。逐项展开board_top端口核对：93个标量端口均有PAD、无多余端口、无方向不符、无重复PAD及冲突属性；新增14项相机位置/方向/电气标签与camera_single.fdc一致，SCL/SDA为INOUT。DDR参考8ns以及core的12/16派生比例与125MHz/93.75MHz设计相符。上述为静态核对，不是物理电气或PDS端点匹配验证。

**当前约束不完整，不能据此认定相机时序通过。** 当前RISCV.pds第491–497行的逻辑约束输入只包含temp_constraint_file.fdc，已无camera_single.fdc引用；temp文件中只有相机IO属性，没有camera_pclk的create_clock、DVP的set_input_delay，也没有FIFO Gray/控制同步/CRC的set_max_delay。本次未发现source或其他相机时序入口。故前一阶段“独立相机FDC已纳入PDS”的描述不再代表当前磁盘状态，未推断是谁或何工具改变了引用。

修复方向：保留现有已合并的相机引脚，将camera_single.fdc的相机时钟、DVP输入预算及CDC约束作为唯一有效时序入口恢复；可以将时序部分合并进当前FDC，或改成被PDS引用的独立相机时序文件，避免维护两份物理引脚。10ns与下降沿0–3ns仍是实现预算，需后续核传感器/板级时序；CDC get_cells/get_pins匹配仍须本版PDS确认。此次按用户“检查”请求只记录结论，未修改FDC/PDS/RTL，未启动PDS或仿真。

**本节更新覆盖上面及下方历史“尚未改RTL”的状态，历史资料分析保持原文。** 用户已确认实物为DOUBLE-DVP载板、底板J10、单目CAM1/J4、自带24MHz振荡器。本次已完成首版RTL、主工程源表和相机独立FDC接入；尚未运行功能仿真、PDS或实板，不能记摄像头通路PASS。CPU性能优化仍暂停。

修改前保存[032源码前像及清单](../../sim/camera/baseline_032_20261015/manifest.json)，包括六个接入RTL及RISCV.pds、旧fdc/soc_ddr3.fdc；原成功仿真/板测目录不动。当前真正由PDS引用的原约束是`constraint_check/temp_constraint_file.fdc`，该文件保持原状，新增相机约束单独放`fdc/camera_single.fdc`。`mycpu_sync.v`、现有IP、ROM/RAM初始化、成功软件BIN/DAT均未修改。当前修改过的桥不再具有032原SHA，不能把032的功能或性能结果算成本版结果。

### 实际实现及边界

| 文件 | 本版行为 |
|---|---|
| `myriscv/ov5640_sccb.v` | core_clk时钟使能分频到约100kHz；SCL/SDA都开漏，输入两拍同步；逐字节检查ACK，寄存器地址写STOP后再读；末字节主机NACK/STOP；20ms事务看门狗，未连接/卡线不报成功 |
| `myriscv/ov5640_config.v`、`ov5640_config_rom.v` | RESETB保持10ms、释放等待40ms；复用且仅复用原0–243项数据，复位条目后独立等待40ms，其余写间隔1ms；读300A/B、3808–380B、4300、501F共8项，全部符合才CONFIG_DONE；配置失败只能全局复位重试 |
| `myriscv/ov5640_capture.v` | PCLK域按高字节在先组成RGB565；每次ARM丢10帧，下一完整帧采集；逐行验证2560字节、帧结束验证720行，FIFO满/长短帧失败；在FIFO写接受处独立计算输入CRC32 |
| `myriscv/camera_mmio.v` | 独立请求/响应从机；固定单帧区，双域复位释放、状态同步、FIFO预取锁存、单拍写DMA、3秒采集/排空超时、ABORT及原子发布；CPU轮询，无相机IRQ |
| `myriscv/camera_ddr_write_arbiter.v` | AW展示前锁住owner，背压期间不换主机；AW/W同拍与分拍都按实际W消费计数；CPU与相机完整事务轮转，只有owner获得AWREADY/WREADY；CPU读通道保持直接连接 |
| `myriscv/afifo_16i_64o_512.v`及三个`ipm2l_*afifo_16i_64o_512.v` | 完整16→256bit异步FIFO包，13bit写水位/9bit读水位/full/empty都接入；RAM包装器有下述三处静态兼容修正，其余三文件逐字不变，原demo全部保留 |
| `myriscv/data_bus_interconnect.v`、`inst_bus_interconnect.v` | Camera窗口0x10002000–0x1000203f；BUSY期间CPU帧区数据访问拒绝；整个保留帧区取指始终Instruction Access Fault；其他译码/响应接续沿用原路径 |
| `myriscv/dual_sram_to_pango_ddr_bridge.v` | 相机启用时，局部0x01000000–0x011fffff不命中、不填充D缓存，不更新D缓存写命中；填充判断绑定锁存请求标签；其他区域保留I64/D64及posted策略 |
| `myriscv/soc_top.v`、`soc_ddr3_top.v`、`board_top.v` | 分层连接MMIO与相机，板顶启用Camera；PCLK经GTP_CLKBUFG；SCCB由已有93.75MHz域控制，不新增27MHz/XVCLK；独立soc_top/soc_ddr3_top默认ENABLE_CAMERA=0保留旧TB兼容 |

首版有意采用**单个256bit拍一事务**（AWLEN=0），不是16拍burst。每次先从FIFO取出并锁存32字节，再公开AW，避免无WVALID用户口因FIFO空洞写错；首地址0x00400000，实际W消费后地址加8，共57600次。所有权只在本事务W消费后释放，CPU不能被相机WREADY误排空。未增加DDR B响应或RREADY假接口；完成口径沿用现有桥的Pango原生WREADY实际消费，不把wusero_last当作额外B响应。

ABORT/错误不撤回已经公开的AW，也不复位共享DDR；未公开的预取可以丢弃，已经公开/接受的事务继续用已锁存数据排空。若DDR永久不接受，ERROR/TIMEOUT置位但BUSY保持，等待用户全局复位；不会为退出超时而串改owner。FIFO及采集状态在空闲期间复位，两个域各自同步释放；重新ARM准备期等待PCLK域已退出复位及旧终态清除。PCLK停止由core看门狗检出。

FRAME_DONE要求PCLK域正常帧结束、写拍数恰好57600、DMA空闲且无错误；同边沿发布1843200字节、921600像素、递增SEQ及CRC。BUSY解除后不再采集/写帧，直到CPU明确再次ARM；ERROR路径有效长度/像素数/CRC归零。固定帧区0x41000000–0x411fffff，最后有效字节0x411c1fff；固定配置只支持32字节整拍帧，不支持尾字节或动态尺寸/BASE。

### 本版寄存器/软件合同

沿用下方合同草案0x00–0x24的布局，新增**0x28 FRAME_CRC32**（只读）。ID=0x43414d01；只接受4字节对齐的32bit访问，CTRL写要求全四lane strobe。CTRL仅接受1 ARM、2 ABORT、4 CLEAR之一；非法组合/保留offset/写只读项/access size错误返回access fault；busy时ARM/CLEAR拒绝。ARM同时清旧完成/错误元数据，CLEAR不清配置失败，SEQ只在成功时递增。

ERROR_CODE低8位：1 SCCB NACK/卡线超时，2 FIFO overflow，3帧格式，4采集/DDR排空超时，5软件ABORT，6传感器ID不符，7尺寸/格式读回不符，8无效参数/配置状态；配置错误时[15:8]保留最后配置表索引。SCCB NACK和卡线共用码1；当前不提供逐SCCB字节诊断寄存器。

CRC为反射IEEE CRC32：多项式0xedb88320、初始0xffffffff、最终取反；按DDR实际小端字节序（每像素低字节再高字节）计算，与`zlib.crc32(frame_bytes)`口径相同。PCLK结果在成功终态冻结，core在同步DONE且DMA排空后采样，然后才释放FIFO复位。CPU程序应轮询CONFIG_DONE且无ERROR → SW写ARM → 轮询DONE/ERROR → 验BASE/SIZE/PIXEL_COUNT/SEQ → 逐字节读取整帧计算CRC并比较0x28 → 可再ARM。成功Loader/镜像未换，尚无此流程的可执行板测BIN；由Sol在时序通过后编写关键测试/CPU校验程序，DeepSeek仅执行。

### 静态审查、约束及待验收

- [源码审查清单](../../sim/camera/static_20261015/source_review.json)：核46项原参考文件身份保持、244项配置值逐项一致、032前像完整、10项新RTL在PDS设计/仿真源表各一次、14个相机PAD互不冲突且不占当前约束已用PAD。所有实际输入SHA见清单。
- 静态语法/部分展开命令：`iverilog -g2005 -tnull -i -I myriscv -s board_top myriscv/*.v`，仅编译到null，**没有vvp/vsim或测试刺激执行**。最终日志见`sim/camera/static_20261015/iverilog_final.log`；`-i`允许缺省厂家/现有IP黑盒，剩余core_clk/ddr_init_done方向警告由未展开ddr3产生。此结果不能替代完整厂家库编译、仿真或PDS。
- 初次语法错误和警告日志保留。仅对新增FIFO RAM包装器副本修正复制次数表达式`{{8*DATA_LOOP_NUM}{1'b1}}`→`{(8*DATA_LOOP_NUM){1'b1}}`；两个CS常量译码块改为显式地址/复位敏感列表，避免参数消除全部`@*`敏感项后仿真从不触发。并未改容量、字宽、指针、DRM端口或原demo；Sol须用厂家原语验证复位后首读、槽顺序和读延迟。
- FDC相机14脚来自已确认J10/CAM1映射，SCL/SDA方向改INOUT并开漏，上拉保持载板2.8V。LVCMOS33表示FPGA bank接口，不能解读为把DOVDD改3.3V；原理图、传感器电气说明见下方资料。
- PCLK按demo的10ns实现上限约束；DVP下降沿发数、0–3ns输入延迟为**本版实现预算，不是实测传感器/走线保证**。须核实际极性/频率及板级余量后才能声称外部I/O时序闭合。FIFO Gray跨域、控制同步和冻结CRC总线采用具体端点`set_max_delay -datapath_only 10ns`，未添加整域false path。语法依据本机`User_Constraint_Editor_User_Guide.pdf`的set_max_delay章节；PDS映射后必须确认端点匹配，未匹配不能当已覆盖。异步复位释放路径仍需在本版PDS中审查，不能静态宣称时序PASS。
- 最后一次参数防护、FIFO兼容修订后应以最终日志/输入清单为准；早期日志只保留调试事实。`git diff --check -- myriscv RISCV.pds doc/CODEX_HANDOFF.md`无新增空白错误；工作树其他历史空白问题未清理。

**下一步仅由用户重新打开根目录RISCV.pds，保持board_top，执行本版实现并检查时序和约束匹配；暂不以实现结果直接下载验收。** 有违例/约束未匹配交回本对话定位。时序通过后Sol准备一组SCCB/帧与异常/真实CPU共享DDR重复ARM及CRC关键测试，DeepSeek执行；核原始证据通过后再给相机专用软件与KEY0/串口实板步骤。此时不运行历史CoreMark/ISA/物理DDR全套，不把原032或本次语法检查记录成相机功能PASS。

## 1. 结论与最小第一阶段

### 2026-10-15接续：实现前源码核对与设计合同草案

本次已读取AGENTS、HANDOFF顶部及本清单，检查`git status --short`与`git diff`。当前HEAD为`4ee48abbe75f8a6609e961ef7858568be1ed6f5a`；`git diff -- myriscv RISCV.pds`为空，工作树其他历史修改/删除/未跟踪内容保留。主桥SHA256仍为`f14b16cb97fa24fd17050995a1b254933aea5bca3b4a071a33712c7a17c52ba0`，与032成功入口一致。本段是源码核对和拟实施合同，**尚未实现摄像头RTL，也不是PDS/仿真/实板结论**。

用户本次指定本对话承担RTL设计与修改，Sol负责精简测试代码/方案/原始证据，DeepSeek仅执行，用户负责PDS/下载/实板；不沿用历史DeepSeek编写测试的分工。

已直接核对当前board_top、soc_ddr3_top、soc_top、I/D互连、DDR桥、demo配置表/采集器/FIFO wrapper及FIFO核心连接：

- 当前板级仍为x32/256bit/28bit地址，原生地址单位4字节；AGENTS中的x16/128bit是旧描述，不能用来实现本次DMA。保持现有DDR IP与93.75MHz域。
- 当前CPU写缓冲实际完成条件是`write_buffer_valid && axi_wready && (write_buffer_aw_sent || axi_awready)`。新增仲裁必须隔离每个owner的AWREADY/WREADY，尤其覆盖AW/W同拍；不能把相机的WREADY广播给CPU。原桥未使用wusero_last完成CPU单拍，不能在没有协议依据时将其改成标准AXI B响应。
- 当前`inst_bus_interconnect`没有帧区执行限制。若承诺帧区不可执行，应在指令DDR译码前排除保留窗口，以既有Instruction Access Fault响应结束；只在文档禁止跳转并不等于硬件不可执行。
- 当前D命中、填充、写命中更新均需纳入无缓存窗口判定。桥接收的是DDR局部字节地址，应对局部`0x01000000–0x011fffff`判断，不能拿绝对`0x41000000`直接比较。填充使用已锁存请求身份，不能使用此时已改变的CPU地址。
- 已核CoreMark两个linker均把程序/数据/栈限定在`0x40000000`起64KiB，Loader示例程序也在该范围；与建议帧区不重叠。这不是对未来所有Loader下载地址的保证，相机测试软件仍须显式限制程序/堆/栈与下载范围。
- FIFO wrapper实为16→256bit、写水位13bit、读水位9bit，OUTPUT_REG=0；FIFO核心把rd_en连接到存储器rd_clk_en。DMA应显式安排读请求与后续数据锁存，再允许AW，不把非空当作组合首字有效。字序及厂家原语读延迟仍须由Sol关键用例确认。

拟实施的数据合同：固定1280×720 RGB565；每行2560字节、每帧921600像素/1843200字节/57600个32字节拍。CPU帧首地址`0x41000000`，最后有效字节`0x411c1fff`，保留窗口至`0x411fffff`。原生首地址`0x00400000`，拍地址加8；16拍burst时每次加128、共3600次。像素0放拍[15:0]，像素1放[31:16]；传感器先到高字节，CPU内存按小端存储完整16bit像素。帧参数首版只读，避免运行期修改BASE/SIZE带来额外CDC及越界行为。

拟实施控制序列：配置与ID读回成功 → 丢启动帧 → IDLE → ARM清旧完成状态并完成FIFO复位握手 → 等待完整帧起点 → CAPTURE → DRAIN → 原子发布DONE/有效字节数/像素数/序号 → CPU持有。CPU显式再次ARM才允许覆盖。每行结束验证2560字节和偶数字节相位，并在帧结束验证720行；不能仅达到总像素数就提前宣布正常帧。短帧、长行、多行、FIFO满、超时或ABORT均令本帧无效。

拟实施Camera MMIO为`0x10002000–0x1000203f`，仅接受对齐32bit读写；其他size/未对齐/保留偏移或向只读寄存器写入返回access fault，无副作用。CTRL要求SW及全四lane strobe；命令仅在请求接受边沿执行一次。下面仍是待实现合同：

| 偏移 | 寄存器 | 合同 |
|---|---|---|
| 0x00 | ID | 只读，相机外设版本标识；不与传感器ID混淆 |
| 0x04 | CTRL | bit0 ARM、bit1 ABORT、bit2 CLEAR；多命令同写返回error；busy时ARM/CLEAR返回error；ABORT不复位共享DDR |
| 0x08 | STATUS | bit0 CONFIG_DONE、bit1 BUSY、bit2 FRAME_DONE、bit3 OVERFLOW、bit4 ERROR；失败原因独立锁存 |
| 0x0c | FRAME_BASE | 只读0x41000000 |
| 0x10 | FRAME_BYTES | 本次成功发布的有效字节数，未成功为0 |
| 0x14 | FRAME_SEQ | 仅完整成功帧递增；ARM/失败不递增 |
| 0x18 | PIXEL_COUNT | 成功发布的像素数；与DONE一起更新 |
| 0x1c | ERROR_CODE | 区分SCCB NACK/ID/帧格式/溢出/超时/ABORT/DDR协议异常 |
| 0x20 | SENSOR_ID | 只读，SCCB实际读回的300A/300B值 |
| 0x24 | WRITTEN_BEATS | 当前已实际消费的DDR拍数，供失败定位；不是DONE替代条件 |

SCCB抽取0–243项配置数据，重写事务控制：SDA开漏释放/输入采样、每个写字节检测ACK、16bit寄存器寻址读300A/B，读末字节由主机NACK后STOP；移除244–247项。软件复位3008=82之后必须独立等待，不把固定“写间隔”当作传感器复位等待。CONFIG_DONE要求全部有效写与ID=0x5640，并建议读回3808–380B/4300/501F确认尺寸和格式。固定控制时钟可用现有core_clk配分频时钟使能，所有上电/复位时间以参数实际频率换算，不新增逻辑分频时钟；实际载板的24MHz XVCLK与PCLK保持各自含义。

CDC采用请求/应答或保持到确认的电平，不跨域传单拍脉冲。固定帧参数不跨域逐bit采样；PCLK域冻结帧结果后再通知core域采样，直到确认前保持。FIFO两域复位异步置位、各自同步释放；重新ARM前须确认双方已清空并退出复位。PCLK停止时由core域超时报错，不伪造采集完成。

写DMA在发AW前备齐本burst全部有效数据，防止Pango无WVALID口因FIFO空洞消费错误数据。仲裁在AW背压期间也保持选中owner/地址稳定；接受AW后直到全部W消费完毕保持所有权，公平轮转以完整有限burst为单位。ABORT/采集失败后停止产生新burst，但已对DDR公开且等待接受的AW不能随意撤回，已接受的burst必须用已备好的数据完成；排空后再清FIFO与释放busy。超时可以报错，但不能擅自释放尚未完成的DDR owner使下一主机串写；无法排空时保留busy/error等待全局复位。FRAME_DONE同时要求正常帧结果、精确写拍数、DMA及owner均排空，无任何错误。

硬件待确认：已向用户询问实物是否为DOUBLE-DVP载板接J10、单目CAM1/J4、带24MHz振荡器。该信息决定XVCLK/PWDN/RESETB与14项候选引脚是否适用；候选表未自动转为有效FDC。此项不改变内部单帧/无缓存/仲裁合同。后续实现与静态审查完成后由用户先检查PDS时序，再由Sol准备本版关键测试交DeepSeek执行；现在没有可派发的新仿真输入，也没有上板放行。

主要摄像头来源是 [5_1 双目摄像头例程 / ov5640_200k / Top.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/Top.v>)。从中抽取单目0的配置、RGB565采集和写FIFO；**整套Top/DDR主控不能直接覆盖现有SoC**。原工程是双目1280×720各水平缩为640×720，再读DDR拼成HDMI；用户本阶段取原始单目1280×720，先不缩放。

建议第一阶段为**配置/ID读回 → 丢弃启动帧 → ARM后一整帧写DDR → 写完停止并锁住帧 → CPU读取字数/首尾像素/CRC并打印摘要**。先单缓冲，CPU读完后显式重新ARM；以后再增加连续采集/双缓冲。这样先证明真实数据、完整性和CPU可见性，不依赖显示器。

```mermaid
flowchart LR
    C[OV5640 DVP 8bit / PCLK] --> P[RGB565两字节组装与帧边界]
    P --> F[16到256bit异步FIFO]
    F --> W[单帧写DMA / 完成计数]
    W --> A[原生Pango AW/W仲裁]
    B[现有CPU DDR桥] --> A
    A --> D[现有ddr3 IP / core_clk93.75MHz]
    D --> B
    B --> U[CPU从无缓存帧区读取]
    M[Camera MMIO: ARM / DONE / ERR / BASE / SIZE] --> W
    Q[27MHz配置时钟 / SCCB与ID读回] --> C
```

相机本阶段只写DDR，不发AR；CPU可保留独占读地址/读返回路径，新增共享重点是AW/W完整事务的owner、背压与公平性。不能把相机接到只接受CPU32bit请求的data_bus端口，也不能把原生Pango用户口当标准AXI4。

## 2. 源文件：可原样复制的候选

这里“原样”指保持IP核心源不改：仍需接入当前厂家仿真库、保持许可头、验证复位/字序/读延迟，不能只复制wrapper。包名中的64是旧命名，已核真实参数是**WR_DATA_WIDTH16 / RD_DATA_WIDTH256 / WR_DEPTH_WIDTH12 / RD_DEPTH_WIDTH8**，逻辑容量4096个16bit像素词=256个256bit词=8KiB。

| 文件（相对主demo根） | 用途与条件 |
|---|---|
| [prj/source/afifo_16i_64o_512/afifo_16i_64o_512.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_16i_64o_512/afifo_16i_64o_512.v>) | 实际16→256bit异步FIFO、4096个16bit写词/256个256bit读词；需保留全部依赖和厂家原语，先验证字序/读延迟/复位 |
| [prj/source/afifo_16i_64o_512/rtl/ipm2l_fifo_v1_10_afifo_16i_64o_512.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_16i_64o_512/rtl/ipm2l_fifo_v1_10_afifo_16i_64o_512.v>) | 实际16→256bit异步FIFO、4096个16bit写词/256个256bit读词；需保留全部依赖和厂家原语，先验证字序/读延迟/复位 |
| [prj/source/afifo_16i_64o_512/rtl/ipm2l_fifo_ctrl_v1_1_afifo_16i_64o_512.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_16i_64o_512/rtl/ipm2l_fifo_ctrl_v1_1_afifo_16i_64o_512.v>) | 实际16→256bit异步FIFO、4096个16bit写词/256个256bit读词；需保留全部依赖和厂家原语，先验证字序/读延迟/复位 |
| [prj/source/afifo_16i_64o_512/rtl/ipm2l_sdpram_v1_10_afifo_16i_64o_512.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_16i_64o_512/rtl/ipm2l_sdpram_v1_10_afifo_16i_64o_512.v>) | 实际16→256bit异步FIFO、4096个16bit写词/256个256bit读词；需保留全部依赖和厂家原语，先验证字序/读延迟/复位 |

配置ROM中**0–243条的数据内容**可沿用当前1280×720/RGB565模式的起点，尤其3808/3809=0x0500、380A/380B=0x02D0、4300=0x61、501F=0x01；但data_init.v整个控制模块属于下节“必须修改”，尾4条不是有效配置。手册确认4300=0x61对应RGB565红/绿高字节在前，camera_data的两字节拼接方向相符；FIFO到CPU的像素槽/字节顺序仍须独立验证。

## 3. 必须适配后接入的文件

主demo根为`100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k`，下表每项可直接打开原文件。

| 文件 | 需要更改的内容 |
|---|---|
| [rtl/camera/data_init.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/camera/data_init.v>) | 复用0–243项寄存器配置数据；去掉244–247的只读ID占位写，修末项越界/多触发，处理ACK/读回与所需等待 |
| [rtl/camera/SCCB.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/camera/SCCB.v>) | 27MHz/250kHz、0x78写设备地址可借；当前SDA为推挽输出且ACK位驱动0，无读回/NACK，必须改SDA方向/开漏与配置成功判据 |
| [rtl/camera/camera.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/camera/camera.v>) | 复用上电/复位控制结构；按实际配置时钟参数化计数，PWDN实际载板接法与域复位/状态同步需适配 |
| [rtl/camera/camera_data.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/camera/camera_data.v>) | 复用8bit两拍拼RGB565；参数化尺寸/启动丢帧，同步cfg_done和ddr_init，处理断帧/字节相位/异常帧丢弃 |
| [rtl/cmos_write_req_gen.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/cmos_write_req_gen.v>) | 复用VSYNC请求握手思路；不能以VSYNC发布读帧，需写完成/CPU所有权/单帧停止，并同步返回ACK |
| [rtl/frame_ddr3/frame_fifo_write.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/frame_ddr3/frame_fifo_write.v>) | 复用水位→burst→finish控制骨架；明确单位、尾burst/溢出/单帧提交/复位，禁止帧请求静默丢弃旧帧 |
| [rtl/frame_ddr3/frame_read_write.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/frame_ddr3/frame_read_write.v>) | 仅抽取write_buf/write控制；修水位高位未驱动，接full/empty；CPU读帧不需要HDMI读FIFO |
| [rtl/frame_ddr3/aq_axi_master_256.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/frame_ddr3/aq_axi_master_256.v>) | 不直接接本工程；字节地址/原生word地址与LEN宽度不一致，WR_FIFO_RE计数用RD_LEN，BVALID常1不可作为真实完成 |
| [rtl/frame_ddr3/mem_write_arbi.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/frame_ddr3/mem_write_arbi.v>) | 仅借按完整burst保留owner的思路；该模块不是CPU与相机Pango端口仲裁器，需原生AW/W仲裁/限额/返回路由 |
| [rtl/Top.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/Top.v>) | 只作为原链路索引；去双目缩放和HDMI，不替换board_top，不复制旧帧地址/长度/时钟/DDR IP |
| [ov5640.fdc](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/ov5640.fdc>) | 单目通道0引脚候选可与J10映射核对；按实接载板合并、SDA改方向、核2.8V/3.3V与PCLK时序，不整份覆盖 |

### 已发现的具体静态问题（不是仿真结论）

1. **配置末项越界与只读写**。data_init.v的REG_NUM248、数组0..247、reg_num在末项cfg_end_pos从247加到248，同时cfg_start条件仍按旧247<248触发，cfg_done下一拍才有效；存在访问cfg_data_reg[248]和额外配置启动窗口。244–247均为300A00，数据手册PDF101把300A/300B列为只读芯片ID0x56/0x40，应移出写表并用SCCB读验证连接。调整条目数和末项判定，不能用X值/无ACK完成证明配置成功。
2. **SCCB不检测应答**。SCCB.v的SDA是output，器件/高地址/低地址/数据状态的第9位主动拉0，既未释放也未采样从机ACK。sccb_done只表示计时FSM到STOP。需输出使能/开漏、SDA输入和显式NACK/超时、16bit寄存器读回；SCL/SDA上拉以实际载板为准。
3. **复位/上电时间不是注释数字**。camera.v使用0x40000/0xffff/0xfffff计数；27MHz下约9.71ms/2.43ms/38.84ms，若直接改93.75MHz则约2.80ms/0.699ms/11.18ms，低于数据手册PDF29相应5ms/1ms/20ms条件。应保留27MHz控制或参数化重新计算，不能仅改端口时钟。camera_data直接使用配置域init_done和core域ddr_init，也需同步。GPIO载板PWDN固定下拉时camera_pwnd输出实际未连接，必须按真实接线区分。
4. **FIFO计数高位未驱动**。frame_read_write.v的rdusedw/wrusedw为16bit，但只连接[8:0]，高位没有赋值；frame_fifo_write用整个16bit比较BURST_SIZE。应精确宽度或显式零扩展。当前wr_full/rd_empty也悬空；摄像头不能被普通ready反压，应定义overflow丢整帧并报告，不能无声漏像素。
5. **帧长度错配**。原Top缩放后640×720×2=921600字节=28800个32字节数据拍，却传write_len129600；aq主控WR_LEN从burst_len<<5得到字节数，因此129600拍对应4147200字节，与数据流不符。本阶段不缩放1280×720×2=1843200字节=57600拍；若16拍一burst，则3600个burst且无尾拍。任何后续尺寸变化必须重新推导尾burst和Wstrb。
6. **地址/长度单位和DDR完成不能照搬**。aq主控输出32bit字节风格地址，Top直接接28bitPango口（没有当前桥的x32字地址转换），AWLEN从8bit收窄4bit，axi_rid/axi_rlast声明也与IP口宽不一致；WR_FIFO_RE计数用RD_LEN，混用了读/写长度。Top的BVALID固定1，BID/BRESP无实际驱动。改用当前IP的真实AW/W接受/写末拍确认口径，不能沿用假BVALID作为帧完成。
7. **帧归属/CDC**。cmos_write_req_gen在VSYNC时更新read_addr_index，没有等待write_finish；原Top也把write_finish丢弃。CPU场景需最后数据拍已完成后才发布FRAME_DONE/BASE/SIZE/SEQ，CPU持有期间不可重写。write_req_ack跨core到PCLK未同步，帧索引/长度多bit不能只各打一两拍便假定原子；使用稳定数据加握手，第一阶段固定参数可减少跨域配置。
8. **当前D64缓存无外部写一致性**。现有桥仅看CPU本端写去更新/失效缓存，相机旁路DMA不可见；FENCE只是排空不能视为自动invalidate。应为帧区实现no-hit/no-fill无缓存访问，或暂时明确关闭D buffer作为bring-up配置；不能只给C指针加volatile。仅单帧首次读取可规避部分旧缓存风险，但重复ARM验证必须避免上一帧缓存残留。

## 4. 其他demo里更合适的骨架与可供后续设计使用的文件

H表示`100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source`。4_12是使用手册4详细讲解的帧缓冲/DDR链；可借它的行打包与16beat调度骨架来替代5_1的aq主控，**二者选择一种，不两套混接**。4_12的wr_ctrl仍有假AXI兼容口、axi_wvalid=axi_wready及完成取axi_wlast等做法，也必须按当前原生Pango协议和CPU仲裁重新审查，不是整套可直接使用的DMA。

| 文件 | 可借内容 |
|---|---|
| [H/rtl/wr_buf.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source/rtl/wr_buf.v>) | 手册4对应的行缓冲/像素打包/原生16beat写控制；默认HDMI/1920×1080，仍须CPU共享仲裁、宽度/单位/完成握手适配，不与5_1链路同时整套引入 |
| [H/rtl/wr_cmd_trans.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source/rtl/wr_cmd_trans.v>) | 手册4对应的行缓冲/像素打包/原生16beat写控制；默认HDMI/1920×1080，仍须CPU共享仲裁、宽度/单位/完成握手适配，不与5_1链路同时整套引入 |
| [H/rtl/wr_ctrl.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source/rtl/wr_ctrl.v>) | 手册4对应的行缓冲/像素打包/原生16beat写控制；默认HDMI/1920×1080，仍须CPU共享仲裁、宽度/单位/完成握手适配，不与5_1链路同时整套引入 |
| [H/rtl/wr_rd_ctrl_top.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source/rtl/wr_rd_ctrl_top.v>) | 手册4对应的行缓冲/像素打包/原生16beat写控制；默认HDMI/1920×1080，仍须CPU共享仲裁、宽度/单位/完成握手适配，不与5_1链路同时整套引入 |
| [H/rtl/fram_buf.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source/rtl/fram_buf.v>) | 手册4对应的行缓冲/像素打包/原生16beat写控制；默认HDMI/1920×1080，仍须CPU共享仲裁、宽度/单位/完成握手适配，不与5_1链路同时整套引入 |
| [H/rtl/wr_fram_buf/wr_fram_buf.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source/rtl/wr_fram_buf/wr_fram_buf.v>) | 手册4对应的行缓冲/像素打包/原生16beat写控制；默认HDMI/1920×1080，仍须CPU共享仲裁、宽度/单位/完成握手适配，不与5_1链路同时整套引入 |
| [H/rtl/wr_fram_buf/rtl/ipm2l_sdpram_v1_10_wr_fram_buf.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/4_12_HDMI_IN_DDR3_HDMI_OUT/4_12_HDMI_IN_DDR3_HDMI_OUT/HDMI_IN_DDR3_HDMI_OUT/source/rtl/wr_fram_buf/rtl/ipm2l_sdpram_v1_10_wr_fram_buf.v>) | 手册4对应的行缓冲/像素打包/原生16beat写控制；默认HDMI/1920×1080，仍须CPU共享仲裁、宽度/单位/完成握手适配，不与5_1链路同时整套引入 |
| [rtl/hdmi/iic_dri.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/hdmi/iic_dri.v>) | 有SDA输入/方向控制、读操作和ADDR_BYTE参数；ACK条件被注释且无显式NACK输出，不可直接视为可靠SCCB读回驱动 |
| [100K200KMINI/2_Demo/3_2_HDMI_IN_DDR3_YCbCr/3_2_HDMI_IN_DDR3_YCbCr/HDMI_IN_DDR3_YCbCr/source/img_process/RGB2YCbCr.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/3_2_HDMI_IN_DDR3_YCbCr/3_2_HDMI_IN_DDR3_YCbCr/HDMI_IN_DDR3_YCbCr/source/img_process/RGB2YCbCr.v>) | RGB565到YCbCr/灰度流水线，需验证数值范围和同步延迟 |
| [100K200KMINI/2_Demo/3_3_matrix_tb/3_3_matrix_tb/martix_test/source/matrix_3x3.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/3_3_matrix_tb/3_3_matrix_tb/martix_test/source/matrix_3x3.v>) | 后续3×3行窗口/图像预处理，注意所需行FIFO和分辨率参数 |
| [100K200KMINI/2_Demo/3_3_matrix_tb/3_3_matrix_tb/martix_test/source/matrix_tb.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/3_3_matrix_tb/3_3_matrix_tb/martix_test/source/matrix_tb.v>) | 图像刺激与波形参考，不是摄像头到真实CPU/DDR验收TB |
| [100K200KMINI/2_Demo/3_9_HDMI_IN_DDR3_sobel/3_9_HDMI_IN_DDR3_sobel/HDMI_IN_DDR3_sobel/source/img_process/sobel.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/3_9_HDMI_IN_DDR3_sobel/3_9_HDMI_IN_DDR3_sobel/HDMI_IN_DDR3_sobel/source/img_process/sobel.v>) | 后续灰度窗口边缘检测，需配matrix_3x3，首轮不引入 |
| [100K200KMINI/2_Demo/3_1_img_sim/matlab/img2txt.m](<D:/riscv/RISCV/100K200KMINI/2_Demo/3_1_img_sim/matlab/img2txt.m>) | 图像到像素文本刺激工具，当前RGB888且输入文件硬编码，改RGB565/尺寸/路径后可辅助独立测试 |
| [100K200KMINI/2_Demo/3_1_img_sim/matlab/fpga_hex2img.m](<D:/riscv/RISCV/100K200KMINI/2_Demo/3_1_img_sim/matlab/fpga_hex2img.m>) | 导出数据重建图像参考，当前三通道/1280×720/旋转硬编码，不直接验证本次RGB565字序 |

iic_dri虽然有sda_in/sda_out_en、读操作和ADDR_BYTE，但S_ACK条件中的sda_in判断被注释，busy结束不等于传感器ACK；若借它，设16bit寄存器地址（ADDR_BYTE2）、器件地址0x3c/0x78方向语义明确并补错误输出。图像算法/Matlab辅助工具仅作以后处理/测试素材，不放进首阶段关键路径；matrix_tb不含真实CPU和共享DDR，不能作为通路通过证据。

## 5. 第一阶段不要引入的显示/双目/旧IP工程

| 文件 | 去向 |
|---|---|
| [rtl/frame_ddr3/frame_fifo_read.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/frame_ddr3/frame_fifo_read.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/frame_ddr3/mem_read_arbi.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/frame_ddr3/mem_read_arbi.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/video_rect_read_data.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/video_rect_read_data.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/sync_vg.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/sync_vg.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/timing_gen_xy.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/timing_gen_xy.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/video_scale_down.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/video_scale_down.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/hdmi/rgb2tmds.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/hdmi/rgb2tmds.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/hdmi/outputserdes.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/hdmi/outputserdes.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [rtl/hdmi/tmds_encoder.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/rtl/hdmi/tmds_encoder.v>) | CPU直接读DDR不需显示读链；双目/缩放/HDMI以后再用，缩放还需整改把frame_sync当时钟及除法实现 |
| [prj/source/afifo_64i_16o_128/afifo_64i_16o_128.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_64i_16o_128/afifo_64i_16o_128.v>) | 实际256→16bit读FIFO依赖包，后续显示/流式输出使用；CPU本阶段走已有DDR读桥 |
| [prj/source/afifo_64i_16o_128/rtl/ipm2l_fifo_v1_10_afifo_64i_16o_128.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_64i_16o_128/rtl/ipm2l_fifo_v1_10_afifo_64i_16o_128.v>) | 实际256→16bit读FIFO依赖包，后续显示/流式输出使用；CPU本阶段走已有DDR读桥 |
| [prj/source/afifo_64i_16o_128/rtl/ipm2l_fifo_ctrl_v1_1_afifo_64i_16o_128.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_64i_16o_128/rtl/ipm2l_fifo_ctrl_v1_1_afifo_64i_16o_128.v>) | 实际256→16bit读FIFO依赖包，后续显示/流式输出使用；CPU本阶段走已有DDR读桥 |
| [prj/source/afifo_64i_16o_128/rtl/ipm2l_sdpram_v1_10_afifo_64i_16o_128.v](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/source/afifo_64i_16o_128/rtl/ipm2l_sdpram_v1_10_afifo_64i_16o_128.v>) | 实际256→16bit读FIFO依赖包，后续显示/流式输出使用；CPU本阶段走已有DDR读桥 |
| [prj/ov5640.pds](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/ov5640.pds>) | 仅查看源闭包，不替换本项目PDS；旧Top/双目/显示/DDR配置不是当前SoC |
| [prj/ipcore/DDR_200H/DDR_200H.idf](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/ipcore/DDR_200H/DDR_200H.idf>) | 旧IP1.10、DFI_CLK_PERIOD8000；当前IP1.16a/10666，不替换既有成功DDR |
| [prj/ipcore/clk_hdmi/clk_hdmi.idf](<D:/riscv/RISCV/100K200KMINI/2_Demo/5_1 双目摄像头例程/ov5640_200k/prj/ipcore/clk_hdmi/clk_hdmi.idf>) | HDMI像素/串行时钟IP；CPU读取路径不需要 |

DDR_200H.idf与当前ddr3.idf均PG2L200H/FBB676、125MHz参考、x32/256bit数据/28bit地址，但demo版本**1.10/DFI_CLK_PERIOD8000**，当前**1.16a/10666**；即使引脚相似也不能覆盖当前已成功的IP/PHY/时钟。当前核心93.75MHz保持，demo的帧/显示/等待常量按当前时钟重新核。prj的综合/布局布线/位流/报告仅历史产物，不进入新源闭包。

## 6. 硬件接线与手册定位

单目选择demo通道0，按本资料包DOUBLE-DVP载板的CAM1/J4，接底板J10；载板自身的40P座标为J17。这是**针对所给原理图的候选映射**，必须确认用户实物确实是该载板/J10；不是任意OV5640模块通用FPC线序。

已把ov5640.fdc逐项与[mini-base管脚映射.xlsx](<D:/riscv/RISCV/100K200KMINI/3_Hardware/FPGA管脚分配/mini-base管脚映射.xlsx>)的“新底板”J10列AB/AH，以及载板原理图J17管脚核对，以下14项相符。未在实物上确认接线、翻转方向或电平。

| demo端口 | J17/J10管脚号 | FPGA PAD | 表格来源格 |
|---|---:|---|---|
| camera_data_0[7] | 3 | R21 | 新底板!AB7 |
| SDA_0 | 4 | R20 | 新底板!AH7 |
| camera_data_0[5] | 5 | N19 | 新底板!AB8 |
| SCL_0 | 6 | P19 | 新底板!AH8 |
| camera_data_0[4] | 7 | M25 | 新底板!AB9 |
| camera_data_0[0] | 8 | M24 | 新底板!AH9 |
| camera_href_0 | 9 | T25 | 新底板!AB10 |
| camera_data_0[6] | 10 | T24 | 新底板!AH10 |
| camera_data_0[1] | 11 | R22 | 新底板!AB11 |
| cam_rst_0 | 12 | T22 | 新底板!AH11 |
| camera_data_0[2] | 13 | K26 | 新底板!AB12 |
| camera_data_0[3] | 14 | K25 | 新底板!AH12 |
| camera_vsync_0 | 17 | L23 | 新底板!AB14 |
| camera_clk_0 | 18 | L22 | 新底板!AH14 |

载板原理图PDF1显示U27为**24.00MHz**振荡器，XCLK直接给两个模组，因此该载板不用FPGA产生XCLK；FPGA27MHz系统时钟是SCCB控制时钟（demo sys_clk=D18），PCLK是传感器返回的独立时钟，三个时钟不能混淆。若换成无本地振荡器的模组，必须另外生成并约束XVCLK。PWDN在载板通过电阻下拉，没有从J17导出；RESETB有控制线。应用指南指出8bitRGB565物理数据使用传感器D[9:2]，载板网名D0..D7是重映射，不能按传感器裸脚名接错。

载板DOVDD为2.8V、SCCB上拉到2.8V，而demo约束写LVCMOS33；不要由demo标签认定模块全部3.3V耐受。按实物DOVDD、FPGA bank电压、RESETB/PWDN与开漏上拉核电气及输入采样边沿。当前KEY0=C22、UART=C24等板级接口保持；合并相机FDC时只增已核新端口，不覆盖DDR的时钟/管脚/PHY属性，不以大范围false path掩盖CDC。

手册与新增查到的资料（页码均为PDF实际页，印刷页可能不同）：

| 资料 | 相关位置/用途 |
|---|---|
| [教程1_盘古MINI系列开发板硬件指导手册_V1.3.pdf](<D:/riscv/RISCV/100K200KMINI/1_Demo_document/实验例程说明篇/教程1_盘古MINI系列开发板硬件指导手册_V1.3.pdf>) | 42页；27MHz单端时钟、扩展IO与MINI100HP/200H硬件边界；不是OV5640专用配置手册 |
| [教程2 盘古100K MINI 通用实验指导手册-盘古676系列.pdf](<D:/riscv/RISCV/100K200KMINI/1_Demo_document/实验例程说明篇/教程2 盘古100K MINI 通用实验指导手册-盘古676系列.pdf>) | 177页；DDR/PLL/FIFO工具与工程说明，作为IP使用参考 |
| [教程3 盘古100K MINI 图像实验指导手册-盘古676系列.pdf](<D:/riscv/RISCV/100K200KMINI/1_Demo_document/实验例程说明篇/教程3 盘古100K MINI 图像实验指导手册-盘古676系列.pdf>) | 255页；PDF41/46/52讲RGB565/888及灰度流水线，对后续图像处理有用 |
| [教程4 《国产FPGA权威开发指南》教材配套实验指导手册-盘古676系列.pdf](<D:/riscv/RISCV/100K200KMINI/1_Demo_document/实验例程说明篇/教程4 《国产FPGA权威开发指南》教材配套实验指导手册-盘古676系列.pdf>) | 161页；PDF138（印刷132）列wr_buf的DDR时钟/写请求/数据/帧计数接口，关联4_12源码 |
| [OV5640_DataSheet.pdf](<D:/riscv/RISCV/100K200KMINI/4_IC_datasheet/OV5640/OV5640_DataSheet.pdf>) | 177页；PDF28–30上电时序，PDF87 RGB565输出顺序，PDF101只读ID300A/B，寄存器实际定义优先于demo注释 |
| [OV5640_AF_Imaging_Module_Application_Guide_(DVP_Interface).pdf](<D:/riscv/RISCV/100K200KMINI/4_IC_datasheet/OV5640/OV5640_AF_Imaging_Module_Application_Guide_(DVP_Interface).pdf>) | 63页；PDF6–8 DVP数据位、供电、SCCB上拉及RESETB/PWDN/XCLK电平与接口 |
| [DOUBLE-DVP-OV5640-1113.pdf](<D:/riscv/RISCV/100K200KMINI/4_IC_datasheet/OV5640/DOUBLE-DVP-OV5640-1113.pdf>) | PDF1载板原理图：J4/J5/J17、24MHz振荡器、SCCB上拉、RESET/PWDN和电源 |

已文本检索四份实验手册，**未定位到5_1双目OV5640的专章或其CPU接入步骤**；不能把4_12 HDMI输入路径说成摄像头demo已获手册完整验收。原理图与模组指南已渲染并目视核对；文本提取和输入身份见evidence目录。

## 7. Astra需要接入的本工程边界与建议接口

| 当前文件 | 后续接入职责 |
|---|---|
| [board_top.v](<D:/riscv/RISCV/myriscv/board_top.v>) | 单目PCLK/8bit/HREF/VSYNC/SCCB/RESETB（和需要时27MHz配置钟）板级端口；保持KEY0去抖/125MHz参考 |
| [soc_ddr3_top.v](<D:/riscv/RISCV/myriscv/soc_ddr3_top.v>) | 当前CPU用户口到ddr3的直接线之间加入相机写DMA与AW/W owner仲裁；保持现有IP/DDR校准/93.75MHz复位域 |
| [soc_top.v](<D:/riscv/RISCV/myriscv/soc_top.v>) | Camera MMIO配置/状态与捕获模块边界；CPU轮询先通，不必首阶段IRQ |
| [data_bus_interconnect.v](<D:/riscv/RISCV/myriscv/data_bus_interconnect.v>) | 新Camera MMIO独立译码目标及access-fault/握手，保留已有RAM/MMIO/UART窗口和接续 |
| [dual_sram_to_pango_ddr_bridge.v](<D:/riscv/RISCV/myriscv/dual_sram_to_pango_ddr_bridge.v>) | CPU仍读DDR；明确帧地址窗口no-hit/no-fill或bring-up禁D buffer；相机不直接force缓存或复用CPU请求槽 |

建议新Camera MMIO窗口`0x10002000–0x1000203f`（**只是待实现建议，不是已存在接口**），包含ID/CTRL(ARM,ABORT,CLEAR)/STATUS(CONFIG_DONE,BUSY,FRAME_DONE,OVERFLOW,ERROR)/FRAME_BASE/FRAME_BYTES/FRAME_SEQ/PIXEL_COUNT。所有写命令只在req_valid&&ready接受边沿执行一次；FRAME_DONE与元数据原子发布，RESET/ABORT使半帧无效，CPUACK/ARM控制下一次覆盖。新窗口不要覆盖simple_mmio或UART。

建议先预留CPU字节地址`0x41000000`起2MiB，帧实际1843200字节（0x1c2000），行步长2560字节、32字节对齐；这是规划，不是已改链接脚本。先核既有DDR程序/堆/栈/Loader诊断区不重叠，再设DMA局部offset0x01000000。现x32用户地址单位是4字节，控制器首地址=offset>>2（0x00400000），每个256bit数据拍递增8个原生地址单位；不要把CPU绝对字节地址或demo的帧beat索引直接接入axi_awaddr。固定像素存储合同建议像素0在DDR拍[15:0]、像素1在[31:16]，CPU小端16bit读同序；必须由独立刺激验证而不是从DUT写数据反算期望。

共享写口一次只保留一个完整burst owner，AW接受后保持到其所有W拍实际消费/末拍确认；不因另一主机valid改变WDATA/Wstrb或返回路由。CPU的posted W等待不能被DMA的WREADY误清除；相机不要抢占未完成CPU写，有限burst/公平性防止CPU长期饥饿。Pango无B/RREADY，CPU读返回不可丢，不能靠标准AXI4的WVALID/BVALID/RREADY模型验收。新相机地址范围默认不可执行，CPU不在采集期间读/写该帧，读模式缓存策略必须有明确实现。

## 8. 交给Astra的具体要求与后续最小验证

请Astra先读取AGENTS、HANDOFF顶部和本清单，基于这里的原文件抽取/适配，不复制整个demo工程。交回具体RTL变更、端口/时钟/复位说明、寄存器与帧数据合同、FIFO依赖/IP参数/引脚候选和设计输入身份；不要改现有DDR IP、PHY、成功软件镜像或回滚032。第一阶段只单帧采集、写完成后停止、真实CPU读取，不引入双目/HDMI/缩放/滤波/新性能优化。RTL放myriscv主工程，不另建设计候选副本。

用户检查本版PDS时序，时序通过后Sol再写一组精简关键测试交DeepSeek执行。必要观察收敛为：

1. SCCB/配置模型：每个真实写条目恰好一次、末项不过界、ID读回0x5640；NACK/未连接不假报CONFIG_DONE，上电与复位顺序明确。
2. DVP与FIFO/帧写：两个异步时钟、确定性像素、HREF空隙/字节相位/帧边界、FIFO full或短帧/ABORT/复位不发布成功半帧；按独立刺激比对每字节/拍/地址，不能只看帧中断或波形。
3. 真实SoC共享DDR：CPU与相机AW/W竞争、AW和W背压/分离/末拍，posted不误完成、所有权稳定且CPU不饿死；两次不同图案采集至同一帧区，CPU逐字读取一致，验证缓存策略、数据新鲜度和FRAME_DONE不会早于最后实际写。用一个小CPU程序，复用UART/BSP，不跑历史CoreMark/ISA/PHY全套；只有改DDR IP/PHY/时钟时再决定相关物理DDR测试。

本次没有仿真代码/执行授权或新增PASS；DeepSeek不根据这个清单自行写RTL/测试或试跑。资料交接与实现验收分开。本报告与机器可读列表共53个文件身份；[完整分类/源SHA/接线表JSON](<D:/riscv/RISCV/doc/camera/evidence_2026-10-15/reuse_manifest.json>)用于Astra复核路径，原demo/PDF/XLSX均未改。
