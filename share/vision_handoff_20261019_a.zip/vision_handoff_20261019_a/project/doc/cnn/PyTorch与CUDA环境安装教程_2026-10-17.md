# PyTorch + CUDA 环境安装教程（本机）

2026-10-17。本文是用户自行安装 PyTorch/CUDA 的操作说明，不是阶段验收记录。
安装完成后训练仍需在本机实际执行，训练产物与验收另见
`doc/cnn/手写数字数据准备与INT8训练_2026-10-17.md`。

## 一、目标环境

| 项 | 值 |
|---|---|
| Python | 3.13（wheel 的 `cp313` 标签必须是这个） |
| 平台 | Windows x86-64（`win_amd64`） |
| torch | **2.7.1+cu128** |
| CUDA 运行时 | 12.8（**随 wheel 打包，不要另外装**） |
| 显卡驱动 | 610.62，已满足，不动 |
| GPU | RTX 4070 Laptop 8 GiB |

不需要安装 CUDA Toolkit、不需要 cuDNN、不需要设置 `CUDA_HOME` 或改 PATH。

## 二、要装到哪里（二选一）

| 方案 | 解释器 | 说明 |
|---|---|---|
| **A 隔离环境（推荐）** | `D:\riscv\RISCV\sim\cnn\training_env\Scripts\python.exe` | 只影响本项目，已含 numpy 2.4.4 / pillow 12.2.0 |
| B 全局 | `C:\python\python.exe` | 也能跑，但会污染全局包 |

下文以 A 为例，选 B 就把路径换掉。

## 三、下载 wheel

下载地址（两个都能用，哪个快用哪个）：

- 官方：
  `https://download.pytorch.org/whl/cu128/torch-2.7.1%2Bcu128-cp313-cp313-win_amd64.whl`
- 阿里云镜像（本机实测比官方快）：
  `https://mirrors.aliyun.com/pytorch-wheels/cu128/torch-2.7.1%2Bcu128-cp313-cp313-win_amd64.whl`

文件信息：

- 大小：**3,273,029,450 字节**
- SHA256：`500ad5b670483f62d4052e41948a3fb19e8c8de65b99f8d418d879cbb15a82d6`

保存到（目录当前为空，可直接用）：

```
D:\riscv\RISCV\sim\cnn\training\wheels_20261017_a\torch-2.7.1+cu128-cp313-cp313-win_amd64.whl
```

要点：

1. URL 里的 `%2B` 就是 `+` 号，**不要手动改成 `+`**，否则 404。
2. 单连接实测只有 0.3~2 MB/s，**用多线程下载器（8~16 连接）**，或直接挂机等约 30 分钟。
3. 断过的文件必须重新走完校验，不要凭"看起来下载完了"就安装。

## 四、校验 SHA256（必做）

```powershell
Get-FileHash "D:\riscv\RISCV\sim\cnn\training\wheels_20261017_a\torch-2.7.1+cu128-cp313-cp313-win_amd64.whl" -Algorithm SHA256
```

输出必须等于：

```
500AD5B670483F62D4052E41948A3FB19E8C8DE65B99F8D418D879CBB15A82D6
```

对不上就重下，**不要安装**。

## 五、安装

```powershell
& "D:\riscv\RISCV\sim\cnn\training_env\Scripts\python.exe" -m pip install --no-cache-dir "D:\riscv\RISCV\sim\cnn\training\wheels_20261017_a\torch-2.7.1+cu128-cp313-cp313-win_amd64.whl"
```

`--no-cache-dir` 是必须的：C 盘只剩约 6 GiB，禁止缓存再复制一份 3.27 GB。

如果安装时报磁盘空间不足，把临时目录指到 D 盘再重试：

```powershell
$env:TMP = "D:\riscv\RISCV\sim\cnn\training\tmp"
$env:TEMP = "D:\riscv\RISCV\sim\cnn\training\tmp"
New-Item -ItemType Directory -Force $env:TMP | Out-Null
```

## 六、验证

```powershell
& "D:\riscv\RISCV\sim\cnn\training_env\Scripts\python.exe" -c "import torch;print(torch.__version__);print(torch.version.cuda);print(torch.cuda.is_available());print(torch.cuda.get_device_name(0))"
```

期望输出：

```
2.7.1+cu128
12.8
True
NVIDIA GeForce RTX 4070 Laptop GPU
```

四条全对才算装好。`is_available()` 为 `False` 说明装成了 CPU 版，或者驱动不匹配。

## 七、常见坑

1. **`pip install torch` 不带 `--index-url`** → 从 PyPI 装到 **CPU 版**，
   `torch.version.cuda` 会是 `None`。必须用本教程的本地 wheel 方式。
2. **不要** 额外装 `nvidia-cuda-runtime-cu12`、`nvidia-cudnn-*` 之类的包。
   Windows wheel 已经把 CUDA 运行时打进去了，多装只会冲突。
3. **不要** 加 `--user`：会把包装到用户目录，和 venv 的 site-packages 打架。
4. **不要** 去 NVIDIA 官网下 CUDA Toolkit。装了也不会让 torch 变快，反而可能因版本
   不一致出问题。
5. 下载目录里如果有同名 `.part` 预分配文件（约 3.05 GB 全是零），**必须删掉再下载**，
   否则续传会把零字节当真数据，最后的 SHA 一定不匹配。
6. C 盘 `%TEMP%` 紧张时，pip 会在下载末尾因空间不足失败；按第五节设置 `TMP` 到 D 盘。

## 八、装完之后

告诉已安装的解释器路径，我接着执行（数据已准备并冻结，不需要重新生成）：

```powershell
Set-Location D:\riscv\RISCV
& "<你装好的 python.exe>" -X utf8 tools/cnn_digits_training/train.py `
  --data sim/cnn/training/handwritten_data_20261017_a `
  --out  sim/cnn/training/handwritten_run_20261017_a
```

注意：

- `train.py` 第 299 行硬性要求 `torch.cuda.is_available()` 为真，CPU 版会直接报错退出。
- `--out` 目录必须**不存在**，脚本要求新建，不能覆盖。
- 产出为 100 轮浮点 + 40 轮 QAT + 6222 word 模型包 + 逐层整数一致性验证，
  不涉及任何 RTL/PDS/实板操作。
