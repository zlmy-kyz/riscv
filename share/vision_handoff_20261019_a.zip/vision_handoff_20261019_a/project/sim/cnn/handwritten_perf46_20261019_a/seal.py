import importlib.util
import json
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
specification = importlib.util.spec_from_file_location('handwritten_perf46_pc', ROOT / 'tools/cnn_handwritten_perf46/run.py')
pc = importlib.util.module_from_spec(specification)
specification.loader.exec_module(pc)


def main():
    frozen = HERE / 'sealed_20261019_a'
    ready_path = HERE / 'ready.json'
    if frozen.exists() or ready_path.exists():
        raise ValueError('new seal directory required')
    manifest, model = pc.image()
    hardware = pc.hardware()
    parents = pc.read(HERE / 'parent_identity.json')
    for name, expected in parents.items():
        pc.need(pc.sha(ROOT / name) == expected, 'protected input changed ' + name)
    review_path = HERE / 'checks_02/review.json'
    review = pc.read(review_path)
    pc.need(review['status'] == 'HANDWRITTEN_PERF46_PC_OFFLINE_CHECKS_PASS_NOT_HDL_NOT_BOARD', 'offline checks not accepted')
    for name, expected in review['input_sha256'].items():
        pc.need(pc.sha(ROOT / name) == expected, 'changed tested input ' + name)
    for name, expected in review['artifact_sha256'].items():
        pc.need(pc.sha(review_path.parent / name) == expected, 'changed check artifact ' + name)
    original_ready_path = pc.base.STAGE / 'ready.json'
    original_frozen_path = pc.base.STAGE / 'sealed_20261017_a/manifest.json'
    inherited = pc.read(original_ready_path)['input_sha256']
    original_frozen = pc.read(original_frozen_path)
    pc.need(original_frozen['sha256'] == inherited, 'original archive/ready mismatch')
    for name, expected in inherited.items():
        pc.need(pc.sha(original_frozen_path.parent / 'project' / name) == expected, 'original archive changed ' + name)
    new_inputs = {path for path in HERE.iterdir() if path.is_file() and path.suffix in ('.py', '.json')}
    new_inputs.update([ROOT / 'tools/cnn_handwritten_perf46/run.py', ROOT / 'tools/cnn_handwritten_perf46/README.md',
                       review_path, original_ready_path, original_frozen_path])
    new_inputs.update(path for path in (HERE / 'checks_01').iterdir() if path.is_file())
    project = frozen / 'project'
    project.mkdir(parents=True, exist_ok=False)
    new_hashes = {}
    for path in sorted(new_inputs):
        name = path.relative_to(ROOT).as_posix()
        destination = project / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
        new_hashes[name] = pc.sha(destination)
        pc.need(new_hashes[name] == pc.sha(path), 'copy mismatch ' + name)
    inputs = {**inherited, **new_hashes, **hardware['provenance_sha256']}
    pc.save(frozen / 'manifest.json', dict(status='SEALED_PC_ADAPTATION_NOT_HDL_PACKAGE', sha256=new_hashes,
                                         inherited_software_sha256=inherited,
                                         inherited_archive=original_frozen_path.relative_to(ROOT).as_posix(),
                                         inherited_archive_sha256=pc.sha(original_frozen_path),
                                         design_sha256=hardware['design_sha256'],
                                         constraint_sha256=hardware['constraint_sha256'],
                                         provenance_sha256=hardware['provenance_sha256'],
                                         scope='PC identity and JTAG records only; original software archive reused without rebuild; no HDL package claim'))
    ready = dict(status=pc.READY_STATUS, pc_contract=pc.PC_CONTRACT,
                 firmware_manifest=pc.DEFAULT.relative_to(ROOT).as_posix(), firmware_path=manifest['bin_path'],
                 firmware_sha256=manifest['bin_sha256'], firmware_bytes=manifest['bytes'], firmware_crc32=f"{manifest['crc32']:08x}",
                 model_id=model['meta']['model_id_hex'], model_crc32=f"{model['meta']['load_crc32']:08x}",
                 hardware_manifest_sha256=pc.sha(HERE / 'hardware.json'), input_sha256=inputs,
                 frozen_manifest_sha256=pc.sha(frozen / 'manifest.json'),
                 offline_review=review_path.relative_to(ROOT).as_posix(), offline_review_sha256=pc.sha(review_path),
                 prior_failed_check='checks_01/review.json', historical_inputs_preserved=len(parents),
                 inherited_software_inputs=len(inherited), current_design_inputs=len(hardware['design_sha256']),
                 reset_method='jtag', user_reported_KEY0_press=False, user_JTAG_reload_each_run=True,
                 hardware_bitstream_independently_identified=False, KEY0_warm_reset='UNRESOLVED',
                 new_RTL_changes=False, firmware_rebuilt=False, PDS_started=False, new_PDS_required=False,
                 serial_opened=False, key_HDL='NOT_COMPLETED', real_CPU='NOT_RUN',
                 current_PERF46_camera_CNN_board='NOT_RUN', CPU_CoreMark_PASS_is_not_camera_CNN_PASS=True,
                 formal_camera_accuracy_verified=False, fast_source_to_PP_check=False,
                 full_source_source_to_PP_check='REQUIRED_ALL_27648_BYTES', retry_count=0)
    pc.save(ready_path, ready)
    print(json.dumps(dict(status=ready['status'], inputs=len(inputs), preserved=len(parents),
                          firmware_sha256=manifest['bin_sha256'], serial_opened=False), indent=2))


if __name__ == '__main__':
    main()
