import argparse
import builtins
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
specification = importlib.util.spec_from_file_location('handwritten_perf46_pc', ROOT / 'tools/cnn_handwritten_perf46/run.py')
pc = importlib.util.module_from_spec(specification)
specification.loader.exec_module(pc)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=HERE / 'checks_01')
    output = parser.parse_args().out.resolve()
    output.mkdir(exist_ok=False)
    report = dict(status='RUNNING', evidence_origin='OFFLINE_SYNTHETIC_TEST', serial_opened=False,
                  HDL=False, real_CPU=False, PDS=False, rejections=[], replays={})

    def rejects(name, function, reason=None):
        try:
            function()
        except (ValueError, AssertionError) as error:
            if reason:
                assert reason in str(error), (name, str(error))
            report['rejections'].append(dict(name=name, error=str(error)))
            return
        raise AssertionError('wrongly accepted ' + name)

    def command(name, argv, expected_returncode=0):
        completed = subprocess.run(list(map(str, argv)), cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
        (output / (name + '.log')).write_bytes(completed.stdout)
        pc.save(output / (name + '.command.json'), dict(argv=list(map(str, argv)), returncode=completed.returncode))
        assert completed.returncode == expected_returncode, (name, completed.stdout.decode(errors='replace'))
        return completed.stdout

    try:
        manifest, model = pc.image()
        hardware = pc.hardware()
        assert manifest['bin_sha256'] == '5b3364b064a4687a2e141bef504031fdc31a09d1e681b8cd1518133d4ee9f49c'
        assert pc.reference.MODEL_ID == '4c8b5aca' and len(hardware['changed_from_20261017']) == 6
        rejects('legacy_hardware_still_rejects_current_CPU', pc.base.hardware, 'changed CAM2 design')
        for name in ('wrong_CPU_hash', 'missing_CPU', 'KEY0_reset', 'CAM1', 'two_cameras', 'test_generator', 'wrong_clock', 'wrong_PAD'):
            altered = copy.deepcopy(hardware)
            if name == 'wrong_CPU_hash':
                altered['design_sha256']['myriscv/mycpu_sync.v'] = '0' * 64
            elif name == 'missing_CPU':
                del altered['design_sha256']['myriscv/mycpu_sync.v']
            elif name == 'KEY0_reset':
                altered['reset_method'] = 'key0'
            elif name == 'CAM1':
                altered['camera_connector'] = 'CAM1/J4'
            elif name == 'two_cameras':
                altered['camera_count'] = 2
            elif name == 'test_generator':
                altered['parameters']['CAMERA_DVP_TEST_ENABLE'] = 1
            elif name == 'wrong_clock':
                altered['core_clock_hz'] = 100000000
            else:
                altered['camera_pad_map']['camera_pclk'] = 'L22'
            rejects(name, lambda: pc.validate_hardware(altered))
        plan = json.loads(command('plan', [sys.executable, '-X', 'utf8', ROOT / 'tools/cnn_handwritten_perf46/run.py', '--plan-only']).decode('utf-8'))
        assert plan['reset_method'] == 'jtag' and plan['user_reported_KEY0_press'] is False and not plan['serial_opened']
        assert plan['new_PDS_required'] is False and plan['user_JTAG_reload_each_run'] is True
        command('reject_KEY0_cli', [sys.executable, '-X', 'utf8', ROOT / 'tools/cnn_handwritten_perf46/run.py', '--reset-method', 'key0', '--plan-only'], 2)
        for mode in ('fast', 'full'):
            original = pc.base.STAGE / 'checks_01' / mode / 'pc'
            folder = output / mode
            shutil.copytree(original, folder)
            shutil.copyfile(HERE / 'hardware.json', folder / 'hardware.json')
            pc.save(folder / 'ready.json', dict(status=pc.READY_STATUS, hardware_manifest_sha256=pc.sha(folder / 'hardware.json'),
                                                fixture_origin='OFFLINE_SYNTHETIC_TEST_NOT_PRODUCTION_READY'))
            result = pc.read(folder / 'result.json')
            result.update(pc_contract=pc.PC_CONTRACT, requested_reset_method='jtag', user_reported_KEY0_press=False,
                          serial_opened=False, operator_JTAG_CAM2_confirmation=False,
                          operator_KEY0_kept_released_confirmation=False,
                          hardware_bitstream_independently_identified=False,
                          hardware_manifest_sha256=pc.sha(folder / 'hardware.json'))
            result['file_sha256'] = {path.relative_to(folder).as_posix(): pc.sha(path) for path in folder.rglob('*')
                                     if path.is_file() and path.name not in ('result.json', 'verified.json')}
            pc.save(folder / 'result.json', result)
            reviewed = pc.verify(folder, 'OFFLINE_SYNTHETIC_TEST')
            pc.save(folder / 'verified.json', reviewed)
            assert reviewed['full_source_export'] == (mode == 'full')
            assert len(result['session']['packets']) == (1829 if mode == 'full' else 28)
            report['replays'][mode] = dict(raw_RX_sha256=pc.sha(folder / 'uart.rx.bin'), raw_TX_sha256=pc.sha(folder / 'uart.tx.bin'),
                                           packets=len(result['session']['packets']), reviewed=reviewed)
            rejects('synthetic_not_board_' + mode, lambda: pc.verify(folder), 'synthetic')
        trial = output / 'fast'
        original_result = pc.read(trial / 'result.json')
        altered = copy.deepcopy(original_result)
        altered.update(evidence_origin='ACTUAL_SERIAL', serial_opened=True)
        pc.save(trial / 'result.json', altered)
        rejects('missing_JTAG_operator_confirmation', lambda: pc.verify(trial), 'actual JTAG prerequisites')
        altered.update(operator_JTAG_CAM2_confirmation=True, operator_KEY0_kept_released_confirmation=True, user_reported_KEY0_press=True)
        pc.save(trial / 'result.json', altered)
        rejects('KEY0_press_cannot_be_JTAG_capture', lambda: pc.verify(trial), 'JTAG reset record')
        altered.update(user_reported_KEY0_press=False, hardware_bitstream_independently_identified=True)
        pc.save(trial / 'result.json', altered)
        rejects('operator_is_not_bitstream_readback', lambda: pc.verify(trial), 'not bitstream readback')
        pc.save(trial / 'result.json', original_result)
        provisional = output / 'provisional_stage'
        provisional.mkdir()
        shutil.copyfile(HERE / 'hardware.json', provisional / 'hardware.json')
        pc.save(provisional / 'ready.json', dict(status=pc.READY_STATUS, firmware_sha256=manifest['bin_sha256'], input_sha256={}))
        original_stage, original_input = pc.STAGE, builtins.input
        previous_serial = sys.modules.get('serial')
        constructor_calls = []

        def block_serial(*args, **kwargs):
            constructor_calls.append(dict(args=args, kwargs=kwargs))
            raise ValueError('OFFLINE_SERIAL_CONSTRUCTOR_STUB')

        def cancel(prompt):
            assert 'JTAG' in prompt and 'KEY0保持释放，不再按键' in prompt
            raise KeyboardInterrupt('offline cancellation')

        try:
            pc.STAGE = provisional
            sys.modules['serial'] = SimpleNamespace(Serial=block_serial)
            builtins.input = cancel
            cancel_options = SimpleNamespace(log_dir=output / 'cancel', label=0, session='trial046_01', sample=1, port='DO_NOT_OPEN', full_source=True)
            try:
                pc.live(cancel_options, manifest, model, hardware)
            except KeyboardInterrupt:
                pass
            else:
                raise AssertionError('cancellation not propagated')
            assert not constructor_calls and pc.read(output / 'cancel/result.json')['serial_opened'] is False
            builtins.input = lambda prompt: ''
            confirmed_options = SimpleNamespace(**vars(cancel_options))
            confirmed_options.log_dir = output / 'confirmed_stub'
            rejects('offline_constructor_prevents_actual_serial', lambda: pc.live(confirmed_options, manifest, model, hardware), 'OFFLINE_SERIAL_CONSTRUCTOR_STUB')
            confirmed = pc.read(output / 'confirmed_stub/result.json')
            assert len(constructor_calls) == 1 and confirmed['serial_opened'] is False
            assert confirmed['operator_JTAG_CAM2_confirmation'] and confirmed['operator_KEY0_kept_released_confirmation']
            assert confirmed['user_reported_KEY0_press'] is False and confirmed['hardware_bitstream_independently_identified'] is False
        finally:
            pc.STAGE, builtins.input = original_stage, original_input
            if previous_serial is None:
                del sys.modules['serial']
            else:
                sys.modules['serial'] = previous_serial
        for name, expected in pc.read(HERE / 'parent_identity.json').items():
            assert pc.sha(ROOT / name) == expected, ('protected input changed', name)
        report.update(status='HANDWRITTEN_PERF46_PC_OFFLINE_CHECKS_PASS_NOT_HDL_NOT_BOARD',
                      firmware_unchanged=True, historical_inputs_unchanged=True, new_hardware_sources=54,
                      cancellation_before_serial=True, operator_confirmation_semantics_verified=True,
                      original_math_transport_native_checks_reused=str(pc.base.STAGE.relative_to(ROOT) / 'checks_01/review.json'),
                      actual_PERF46_camera_capture='NOT_RUN')
    except BaseException as error:
        report.update(status='STOPPED_FIRST_OFFLINE_FAILURE', error=repr(error))
        raise
    finally:
        report['input_sha256'] = {path.relative_to(ROOT).as_posix(): pc.sha(path) for path in
                                   [Path(__file__), ROOT / 'tools/cnn_handwritten_perf46/run.py', HERE / 'hardware.json', HERE / 'parent_identity.json']}
        report['artifact_sha256'] = {path.relative_to(output).as_posix(): pc.sha(path) for path in output.rglob('*') if path.is_file()}
        pc.save(output / 'review.json', report)
    print(json.dumps(dict(status=report['status'], rejections=len(report['rejections']), replays=len(report['replays'])), indent=2))


if __name__ == '__main__':
    main()
