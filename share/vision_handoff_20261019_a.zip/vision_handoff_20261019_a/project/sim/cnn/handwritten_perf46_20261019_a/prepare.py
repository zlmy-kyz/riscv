import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OLD_STAGE = ROOT / 'sim/cnn/handwritten_photo_20261017_a'
CPU_STAGE = ROOT / 'sim/cpu_perf_detail/preparation_20261019_a'
CPU_BOARD = ROOT / 'sim/cpu_perf_detail/board/task046_pv300_20261019_040620/identity.json'
CPU_REVIEW = ROOT / 'sim/cpu_perf_detail/board/review_task046_20261019_01/review.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    if (HERE / 'hardware.json').exists() or (HERE / 'parent_identity.json').exists():
        raise ValueError('new preparation required')
    old_ready = read(OLD_STAGE / 'ready.json')
    for name, expected in old_ready['input_sha256'].items():
        assert sha(ROOT / name) == expected, ('original sealed software changed', name)
    after = read(CPU_STAGE / 'after_manifest.json')
    design = {name: value for name, value in after.items()
              if name.startswith(('myriscv/', 'ipcore/')) and Path(name).suffix in ('.v', '.vh', '.svh', '.vp', '.idf')}
    assert len(design) == 54
    for name, expected in design.items():
        assert sha(ROOT / name) == expected, ('not the fixed PERF46 source', name)
    cpu_board = read(CPU_BOARD)
    assert cpu_board['core_clock_hz'] == 93750000 and cpu_board['requested_reset_method'] == 'jtag'
    for name, expected in read(CPU_STAGE / 'review.json')['after_sha256'].items():
        assert design[name] == expected == cpu_board['sha256'][name], name
    assert read(CPU_REVIEW)['status'] == 'TASK046_FIXED_LAYOUT_P_V_SHORT_APPLICATION_46_COUNTER_LOGS_VERIFIED_MEM_ATTRIBUTION_CLOSED_FOR_SAMPLES'
    old_hardware = read(OLD_STAGE / 'hardware.json')
    changed = {name: dict(previous=expected, current=design[name])
               for name, expected in old_hardware['design_sha256'].items() if expected != design[name]}
    assert set(changed) == {'myriscv/data_bus_interconnect.v', 'myriscv/dual_sram_to_pango_ddr_bridge.v',
                            'myriscv/inst_bram_adapter.v', 'myriscv/mycpu_sync.v',
                            'myriscv/simple_mmio.v', 'myriscv/soc_top.v'}
    for name, expected in old_hardware['constraint_sha256'].items():
        assert sha(ROOT / name) == expected, name
    board = (ROOT / 'myriscv/board_top.v').read_text(encoding='utf-8')
    assert '.ENABLE_CAMERA(1), .ENABLE_PREPROCESS(1), .ENABLE_CNN(1)' in board
    assert '.CAMERA_COLORBAR_ENABLE(0)' in board and '.CAMERA_DVP_TEST_ENABLE(0)' in board
    assert 'CORE_CLK_HZ = 93_750_000' in board
    soc = (ROOT / 'myriscv/soc_top.v').read_text(encoding='utf-8')
    bridge = (ROOT / 'myriscv/dual_sram_to_pango_ddr_bridge.v').read_text(encoding='utf-8')
    assert '.PREPROCESS_UNCACHED_ENABLE(ENABLE_PREPROCESS)' in soc and '.CAMERA_UNCACHED_ENABLE(ENABLE_CAMERA)' in soc
    assert "data_req_addr[31:16]==16'h0200" in bridge and "data_req_addr[31:22]==(32'h01000000 >> 22)" in bridge
    provenance = [OLD_STAGE / 'hardware.json', OLD_STAGE / 'ready.json', CPU_STAGE / 'after_manifest.json',
                  CPU_STAGE / 'review.json', CPU_BOARD, CPU_REVIEW]
    hardware = dict(old_hardware)
    hardware.update(version='OV5640_CAM2_J5_J10_CPU_PERF46_20261019_A', core_clock_hz=93750000,
                    reset_method='jtag', requires_new_bitstream=False,
                    implementation_use='USER_RELOADS_EXISTING_PERF46_BITSTREAM_EACH_TRIAL_NOT_NEW_PDS',
                    design_sha256=design, changed_from_20261017=changed,
                    provenance_sha256={path.relative_to(ROOT).as_posix(): sha(path) for path in provenance},
                    current_camera_CNN_board_validation='NOT_RUN', KEY0_warm_reset='UNRESOLVED',
                    actual_downloaded_bitstream_independently_verified=False,
                    CPU_CoreMark_PASS_is_not_camera_CNN_PASS=True,
                    integration_static_review=dict(Camera_PP_CNN_enabled=True, clock_hz=93750000,
                                                   Camera_4MiB_and_PP_64KiB_CPU_read_uncached_wiring_present=True,
                                                   dynamic_cache_coherence_verified=False))
    save(HERE / 'hardware.json', hardware)
    protected = {ROOT / name for name in old_ready['input_sha256']}
    protected.update(ROOT / name for name in design)
    protected.update(ROOT / name for name in old_hardware['constraint_sha256'])
    protected.update(provenance)
    protected.add(ROOT / 'RISCV.pds')
    protected.add(OLD_STAGE / 'sealed_20261017_a/manifest.json')
    protected.update(path for path in (OLD_STAGE / 'sealed_20261017_a/project').rglob('*') if path.is_file())
    save(HERE / 'parent_identity.json', {path.relative_to(ROOT).as_posix(): sha(path) for path in sorted(protected)})
    print(json.dumps(dict(status='PERF46_CNN_INPUT_IDENTITY_PREPARED_NOT_BOARD_PASS', design_inputs=len(design),
                         changes=len(changed), preserved_files=len(protected), serial_opened=False), ensure_ascii=False))


if __name__ == '__main__':
    main()
