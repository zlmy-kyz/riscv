import importlib.util
import json
from pathlib import Path

import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
specification = importlib.util.spec_from_file_location('diagnostic_pc', ROOT / 'tools/cnn_handwritten_perf46/run.py')
pc = importlib.util.module_from_spec(specification)
specification.loader.exec_module(pc)
DATA = ROOT / 'sim/cnn/training/handwritten_data_20261017_a'
CAPTURES = ('handwritten_perf46_trial01_1_01', 'handwritten_perf46_trial01_8_02', 'handwritten_perf46_trial01_8_05')


def metrics(rgb):
    gray = np.asarray(pc.reference.integer.gray(rgb), dtype=np.int16).reshape(32, 32) + 128
    return dict(mean=float(gray.mean()), percentiles=np.percentile(gray, [0, 10, 50, 90, 100]).tolist(),
                fractions_below={str(threshold): float((gray < threshold).mean()) for threshold in (64, 128, 192)},
                center24_mean=float(gray[4:28, 4:28].mean()))


def variants(rgb):
    array = np.frombuffer(rgb, dtype=np.uint8).reshape(96, 96, 3)
    contrast = np.clip(np.rint((array.astype(np.float64) - 64) * (255 / 144)), 0, 255).astype(np.uint8)
    result = {'original': rgb, 'invert_RGB255': (255 - array).tobytes(), 'contrast_RGB64_208': contrast.tobytes()}
    for side in (64, 48):
        start = (96 - side) // 2
        for name, source in [('center_crop', array), ('contrast_center_crop', contrast)]:
            cropped = Image.fromarray(source[start:start + side, start:start + side]).resize((96, 96), Image.Resampling.BICUBIC)
            result[f'{name}{side}'] = cropped.tobytes()
    return result


def main():
    output = HERE / 'input_diagnosis_01'
    output.mkdir(exist_ok=False)
    report = dict(status='RUNNING', scope='Offline diagnostic copies only, not board captures or formal accuracy acceptance',
                  serial_opened=False, RTL_modified=False, model_modified=False, contract_modified=False,
                  original_images_modified=False, transformations='Fixed recipes selected before results; not a parameter search',
                  cases={}, controls={}, training_distribution={})
    inputs = [Path(__file__), ROOT / 'tools/cnn_handwritten_perf46/run.py',
              ROOT / 'tools/cnn_handwritten_photo/run.py', ROOT / 'tools/cnn_handwritten_photo/reference.py',
              ROOT / 'tools/cnn_digits_training/integer_reference.py', DATA / 'dataset.json', DATA / 'dataset.npz']
    try:
        _, model = pc.image()
        for name, expected in pc.read(HERE / 'ready.json')['input_sha256'].items():
            pc.need(pc.sha(ROOT / name) == expected, 'changed sealed dependency ' + name)
        dataset_meta = pc.read(DATA / 'dataset.json')
        pc.need(pc.sha(DATA / 'dataset.npz') == dataset_meta['sha256']['dataset.npz'], 'prepared dataset changed')
        inputs.extend(path for path in pc.MODEL.iterdir() if path.is_file())
        dataset = np.load(DATA / 'dataset.npz', allow_pickle=False)
        train_rgb, train_q, train_labels = dataset['train_rgb96'], dataset['train_q'], dataset['train_labels']

        def evaluate(name, rgb, label):
            folder = output / name
            folder.mkdir(parents=True, exist_ok=False)
            inferred = pc.reference.infer(rgb, model)
            (folder / 'rgb96.bin').write_bytes(rgb)
            (folder / 'gray32.bin').write_bytes(bytes(value & 255 for value in inferred['layers']['gray32']))
            ordered = sorted(range(10), key=lambda index: inferred['scores'][index], reverse=True)
            answer = dict(label=label, prediction=inferred['prediction'], label_match=inferred['prediction'] == label,
                          scores=inferred['scores'], top2=ordered[:2], metrics=metrics(rgb),
                          rgb_sha256=pc.sha(folder / 'rgb96.bin'), gray32_sha256=pc.sha(folder / 'gray32.bin'))
            pc.save(folder / 'scores.json', answer)
            return answer

        for label in (1, 8):
            indices = np.flatnonzero(train_labels == label)
            values = train_q[indices].astype(np.int16) + 128
            means = values.mean(axis=(1, 2))
            report['training_distribution'][str(label)] = dict(count=len(indices),
                    per_image_mean_percentiles=np.percentile(means, [0, 10, 50, 90, 100]).tolist(),
                    pixel_percentiles=np.percentile(values, [0, 10, 50, 90, 100]).tolist(),
                    average_fraction_below128=float((values < 128).mean()))
            for index in indices[:2]:
                rgb = train_rgb[index].tobytes()
                actual_q = np.asarray(pc.reference.integer.gray(rgb), dtype=np.int8).reshape(32, 32)
                pc.need(np.array_equal(actual_q, train_q[index]), 'training input formula differs')
                report['controls'][f'train_label{label}_index{index}'] = evaluate(f'controls/train_{label}_{index}', rgb, label)
        for name in CAPTURES:
            folder = ROOT / 'sim/cnn/board' / name
            verified = pc.verify(folder)
            result = pc.read(folder / 'result.json')
            label = result['sample']['label']
            inputs.extend(path for path in folder.rglob('*') if path.is_file())
            entries = {}
            for variant, rgb in variants((folder / 'rgb96.bin').read_bytes()).items():
                entries[variant] = evaluate(name + '/' + variant, rgb, label)
            pc.need(entries['original']['scores'] == result['session']['scores'], 'diagnostic baseline differs from actual board')
            report['cases'][name] = dict(actual_verification=verified, variants=entries)
        for level in (0, 192, 255):
            report['controls'][f'uniform_RGB{level}'] = evaluate(f'controls/uniform_{level}', bytes([level]) * 27648, None)
        report['status'] = 'FIXED_MODEL_INPUT_DIAGNOSIS_COMPLETE_NOT_BOARD_OR_ACCURACY_ACCEPTANCE'
        report['limitations'] = ['Few fixed diagnostic transformations cannot establish sole causality.',
                                'Training controls are preselected training samples, not new validation accuracy.',
                                'All transformed arrays are PC-only copies and must not replace original capture evidence.',
                                'No hardware intermediate tensors or source-to-PP verification added.']
    except BaseException as error:
        report.update(status='STOPPED_FIRST_DIAGNOSTIC_FAILURE', error=repr(error))
        raise
    finally:
        report['input_sha256'] = {path.relative_to(ROOT).as_posix(): pc.sha(path) for path in inputs}
        report['artifact_sha256'] = {path.relative_to(output).as_posix(): pc.sha(path) for path in output.rglob('*') if path.is_file()}
        pc.save(output / 'review.json', report)
    print(json.dumps(dict(status=report['status'], cases={name: {variant: entry['prediction'] for variant, entry in case['variants'].items()} for name, case in report['cases'].items()},
                          controls={name: entry['prediction'] for name, entry in report['controls'].items()}), indent=2))


if __name__ == '__main__':
    main()
