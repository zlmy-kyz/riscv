import argparse
import importlib.util
from pathlib import Path
import re
import shutil
import sys
import time
import json


ROOT = Path(__file__).resolve().parents[2]
BASE_PATH = ROOT / 'tools/cnn_handwritten_photo/run.py'
sys.path.insert(0, str(BASE_PATH.parent))
specification = importlib.util.spec_from_file_location('fixed_handwritten_protocol', BASE_PATH)
base = importlib.util.module_from_spec(specification)
specification.loader.exec_module(base)
DEFAULT, MODEL = base.DEFAULT, base.MODEL
reference, exchange, Replay = base.reference, base.exchange, base.Replay
sha, read, save, need, Wire = base.sha, base.read, base.save, base.need, base.Wire
STAGE = ROOT / 'sim/cnn/handwritten_perf46_20261019_a'
PC_CONTRACT = 'HANDWRITTEN_PERF46_JTAG_V1'
HARDWARE_VERSION = 'OV5640_CAM2_J5_J10_CPU_PERF46_20261019_A'
READY_STATUS = 'HANDWRITTEN_PERF46_PC_READY_PENDING_BOARD'
PROMPT = ('每次运行前先由你用JTAG重新下载当前046同一位流，无需重新PDS；'
          'CAM2/J5、载板J10，两测试模式0。KEY0保持释放，不再按键，等DDR就绪。'
          '关闭串口助手，白纸黑笔单个数字居中正向，画面稳定后Enter：')


def validate_hardware(expected):
    need(expected['version'] == HARDWARE_VERSION, 'wrong PERF46 hardware version')
    need(expected['camera_connector'] == 'CAM2/J5' and expected['connector'] == 'J10', 'CAM2/J10 required')
    need(expected['camera_count'] == 1 and expected['DDR_frame_buffers'] == 2, 'one camera and two DDR buffers required')
    need(expected['parameters'] == dict(CAMERA_COLORBAR_ENABLE=0, CAMERA_DVP_TEST_ENABLE=0), 'real camera mode required')
    need(expected['core_clock_hz'] == 93750000 and expected['reset_method'] == 'jtag', 'clock/reset contract')
    need(len(expected['design_sha256']) == 54 and len(expected['constraint_sha256']) == 1, 'source identity count')
    need(set(expected['changed_from_20261017']) == {
        'myriscv/data_bus_interconnect.v', 'myriscv/dual_sram_to_pango_ddr_bridge.v',
        'myriscv/inst_bram_adapter.v', 'myriscv/mycpu_sync.v',
        'myriscv/simple_mmio.v', 'myriscv/soc_top.v'}, 'six explicit CPU/integration changes required')
    for name, expected_hash in {**expected['design_sha256'], **expected['constraint_sha256']}.items():
        need(sha(ROOT / name) == expected_hash, 'changed PERF46 design ' + name)
    for name, expected_hash in expected['provenance_sha256'].items():
        need(sha(ROOT / name) == expected_hash, 'changed identity provenance ' + name)
    pads = dict(re.findall(r'define_attribute \{p:(camera_[^}]+)\} \{PAP_IO_LOC\} \{([^}]+)\}',
                           (ROOT / 'constraint_check/temp_constraint_file.fdc').read_text()))
    need(pads == expected['camera_pad_map'] and len(pads) == 14, 'CAM2 PAD map')
    return expected


def hardware():
    return validate_hardware(read(STAGE / 'hardware.json'))


def image():
    old_ready = read(base.STAGE / 'ready.json')
    for name, expected in old_ready['input_sha256'].items():
        need(sha(ROOT / name) == expected, 'changed original sealed software ' + name)
    return base.image()


def verify(folder, origin='ACTUAL_SERIAL'):
    folder = Path(folder)
    result = read(folder / 'result.json')
    need(origin in ('ACTUAL_SERIAL', 'OFFLINE_SYNTHETIC_TEST') and result['evidence_origin'] == origin, 'synthetic evidence is not actual serial')
    need(result['status'] == 'HANDWRITTEN_CAPTURE_DATA_VERIFIED', 'capture did not finish')
    if origin == 'ACTUAL_SERIAL':
        need(result['serial_opened'] and result['operator_JTAG_CAM2_confirmation'] and result['operator_KEY0_kept_released_confirmation'], 'actual JTAG prerequisites')
    need(result['pc_contract'] == PC_CONTRACT, 'wrong PC contract')
    need(result['requested_reset_method'] == 'jtag' and result['user_reported_KEY0_press'] is False, 'JTAG reset record required')
    need(result['hardware_bitstream_independently_identified'] is False, 'operator confirmation is not bitstream readback')
    for name, expected in result['file_sha256'].items():
        need(sha(folder / name) == expected, 'changed evidence ' + name)
    manifest = read(folder / 'manifest.json')
    need(manifest['status'] == 'CNN_HANDWRITTEN_BUILD_STATIC_AUDIT_PASS' and manifest['kind'] == 'cnn_handwritten_photo', 'wrong archived firmware')
    need(manifest == result['application'] and sha(folder / 'manifest.json') == result['manifest_sha256'], 'firmware manifest identity')
    need(sha(folder / 'application.bin') == manifest['bin_sha256'], 'firmware bytes')
    model = reference.load(folder / 'model')
    need(model['meta'] == manifest['trained_model'], 'trained model identity')
    model_offset = manifest['symbols']['model_words'] - manifest['base']
    need((folder / 'application.bin').read_bytes()[model_offset:model_offset + 24888] == (folder / 'model/load_words.bin').read_bytes(), 'embedded model words differ')
    sample = read(folder / 'sample.json')
    need(sample == result['sample'] and sample['purpose'] == 'EXPLORATORY_HANDWRITTEN_TRIAL', 'sample identity')
    need(type(sample['label']) is int and 0 <= sample['label'] < 10, 'sample label')
    expected_hardware = read(folder / 'hardware.json')
    need(expected_hardware['camera_connector'] == 'CAM2/J5' and expected_hardware['connector'] == 'J10' and expected_hardware['camera_count'] == 1 and expected_hardware['DDR_frame_buffers'] == 2, 'CAM2/J10 identity')
    need(expected_hardware['parameters'] == dict(CAMERA_COLORBAR_ENABLE=0, CAMERA_DVP_TEST_ENABLE=0), 'real photo identity')
    need(expected_hardware['version'] == HARDWARE_VERSION, 'wrong PERF46 hardware record')
    ready = read(folder / 'ready.json')
    need(ready['status'] == READY_STATUS and ready['hardware_manifest_sha256'] == sha(folder / 'hardware.json'), 'hardware/ready identity')
    need(result['hardware_manifest_sha256'] == sha(folder / 'hardware.json'), 'hardware manifest digest')
    replay = Replay((folder / 'uart.rx.bin').read_bytes(), (folder / 'uart.tx.bin').read_bytes())
    session = exchange(replay, manifest, folder, model, result['full_source_export'], sample['label'], False)
    need(session == result['session'] and replay.rx_count == len(replay.rx) and replay.tx_count == len(replay.tx), 'raw/session mismatch or extra bytes')
    return dict(status='HANDWRITTEN_PERF46_ONE_SAMPLE_RAW_SCORES_VERIFIED', evidence_origin=origin,
                model_id=reference.MODEL_ID, label=sample['label'], prediction=session['job']['prediction'],
                label_match=session['comparison']['label_match'], cnn_ms=session['comparison']['cnn_ms'],
                requested_reset_method='jtag', user_reported_KEY0_press=False,
                hardware_bitstream_independently_identified=False,
                full_source_export=result['full_source_export'], formal_camera_accuracy_verified=False,
                hardware_layer_dump_verified=False, retry_count=0)


def live(args, manifest, model, expected_hardware):
    need(args.log_dir is not None and not args.log_dir.exists(), 'new --log-dir required')
    need(args.label is not None and args.session is not None and re.fullmatch(r'[A-Za-z0-9_-]{1,64}', args.session), '--label and valid --session required')
    need(args.sample >= 1, 'sample number must be positive')
    ready = read(STAGE / 'ready.json')
    need(ready['status'] == READY_STATUS and ready['firmware_sha256'] == manifest['bin_sha256'], 'software preparation not sealed')
    for name, expected in ready['input_sha256'].items():
        need(sha(ROOT / name) == expected, 'changed sealed input ' + name)
    folder = args.log_dir.resolve()
    folder.mkdir(parents=True, exist_ok=False)
    for source, name in [(DEFAULT, 'manifest.json'), (ROOT / manifest['bin_path'], 'application.bin'), (STAGE / 'hardware.json', 'hardware.json'), (STAGE / 'ready.json', 'ready.json')]:
        shutil.copyfile(source, folder / name)
    shutil.copytree(MODEL, folder / 'model')
    sample = dict(label=args.label, session=args.session, sample_number=args.sample,
                  purpose='EXPLORATORY_HANDWRITTEN_TRIAL', medium='white paper, black pen, centered upright single digit')
    save(folder / 'sample.json', sample)
    result = dict(status='RUNNING', evidence_origin='ACTUAL_SERIAL', serial_opened=False,
                  operator_JTAG_CAM2_confirmation=False, operator_KEY0_kept_released_confirmation=False,
                  requested_reset_method='jtag', user_reported_KEY0_press=False,
                  pc_contract=PC_CONTRACT, hardware_bitstream_independently_identified=False,
                  hardware_manifest_sha256=sha(STAGE / 'hardware.json'), command_argv=sys.argv,
                  application=manifest, manifest_sha256=sha(DEFAULT), sample=sample, port=args.port,
                  full_source_export=args.full_source, retry_count=0, PDS_started=False, key_HDL='NOT_COMPLETED',
                  tool_sha256=sha(Path(__file__)))
    save(folder / 'result.json', result)
    wire = None
    try:
        print(f'MODEL={reference.MODEL_ID} LABEL={args.label} SESSION={args.session} FULL_SOURCE={int(args.full_source)}')
        input(PROMPT)
        result['operator_JTAG_CAM2_confirmation'] = True
        result['operator_KEY0_kept_released_confirmation'] = True
        import serial
        with serial.Serial(args.port, 115200, timeout=.05, write_timeout=2, xonxoff=False, rtscts=False, dsrdtr=False) as port:
            result['serial_opened'] = True
            wire = Wire(port, folder)
            need(port.in_waiting == 0, 'unexpected initial bytes; no flush/retry')
            result['session'] = exchange(wire, manifest, folder, model, args.full_source, args.label, True, print)
            time.sleep(.05)
            need(port.in_waiting == 0, 'extra final serial bytes')
        wire.close()
        wire = None
        result['status'] = 'HANDWRITTEN_CAPTURE_DATA_VERIFIED'
    except BaseException as error:
        result.update(status='STOPPED_FIRST_FAILURE', error=repr(error))
        raise
    finally:
        if wire:
            wire.close()
        result['file_sha256'] = {path.relative_to(folder).as_posix(): sha(path) for path in folder.rglob('*') if path.is_file() and path.name not in ('result.json', 'verified.json')}
        save(folder / 'result.json', result)
    checked = verify(folder)
    save(folder / 'verified.json', checked)
    print(json.dumps(checked, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description='CAM2 handwritten trial on the fixed PERF46 hardware identity')
    parser.add_argument('--port', default='COM9')
    parser.add_argument('--log-dir', type=Path)
    parser.add_argument('--label', type=int, choices=range(10))
    parser.add_argument('--session')
    parser.add_argument('--sample', type=int, default=1)
    parser.add_argument('--reset-method', choices=['jtag'], default='jtag')
    parser.add_argument('--full-source', action='store_true')
    parser.add_argument('--plan-only', action='store_true')
    parser.add_argument('--verify', type=Path)
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify(args.verify), ensure_ascii=False, indent=2))
        return
    manifest, model = image()
    expected_hardware = hardware()
    if args.plan_only:
        print(json.dumps(dict(status='HANDWRITTEN_PERF46_PLAN_NO_SERIAL', pc_contract=PC_CONTRACT,
                              model_id=reference.MODEL_ID, firmware_sha256=manifest['bin_sha256'],
                              hardware_version=HARDWARE_VERSION, full_source_export=args.full_source,
                              reset_method='jtag', user_reported_KEY0_press=False, serial_opened=False,
                              new_PDS_required=False, user_JTAG_reload_each_run=True, prompt=PROMPT),
                         ensure_ascii=False, indent=2))
        return
    live(args, manifest, model, expected_hardware)


if __name__ == '__main__':
    main()

