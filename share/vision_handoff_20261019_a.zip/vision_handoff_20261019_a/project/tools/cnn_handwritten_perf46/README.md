# 当前PERF46硬件上的手写数字试识别

本入口仅适配CPU优化后的源码身份及JTAG恢复步骤，复用原手写应用、串口协议及独立整数参考，不改RTL、不重新构建固件、不要求重新PDS。旧`tools/cnn_handwritten_photo/`及其封存保持，不能用旧入口绕过当前硬件身份差异。

## 固定身份与边界

- 单摄像头CAM2/J5，载板仍接底板J10；A/B仅为DDR双缓冲，COLORBAR与DVP_TEST均0；93.75MHz。
- 当前54项RTL/IP源码及有效FDC绑定`sim/cnn/handwritten_perf46_20261019_a/hardware.json`，来自046封存和实板记录；相对10月17日CNN清单仅明确接受六项CPU/互连改动，不放宽为任意硬件。源码哈希及操作者确认不是FPGA位流回读证明。
- 固定BIN：`tests/cnn_handwritten_photo/build/handwritten_20261017_b/program.bin`，42568字节，SHA256 `5b3364b064a4687a2e141bef504031fdc31a09d1e681b8cd1518133d4ee9f49c`，CRC32 `2157dd62`，装载/入口`0x40000000`。
- 模型`4c8b5aca`，6222个word，加载CRC32 `b9749177`；白纸黑笔、居中正向单个手写数字0–9。不是旧未训练诊断模型05a032af；本地测试准确率不代表CAM2实拍准确率。
- KEY0暖复位未闭合。**每次采样前由用户JTAG重新下载当前046同一位流，KEY0始终保持释放，不再按键，等待DDR就绪**；不需要为本次PC适配重新实现PDS。工具不会操作JTAG/PDS。

## 首张完整采样

1. 白纸黑笔写一个0，正向居中，字符高度先占中央正方形约60%–75%，照明稳定。
2. 关闭串口助手，完成上述JTAG恢复；不要再按KEY0。
3. 使用未存在的新日志目录执行，核对提示并等画面稳定后Enter；Enter是操作者确认，不是硬件自动验证。端口若不是COM9，修改`--port`。

```powershell
Set-Location D:\riscv\RISCV
python -X utf8 tools/cnn_handwritten_perf46/run.py --port COM9 --label 0 --session trial046_01 --sample 1 --full-source --log-dir sim/cnn/board/handwritten_perf46_trial01_0_01
```

首张完整源导出约3分钟或更久：1843200字节源帧、27648字节RGB96、1829个CN03数据包；独立核源CRC、源到PP全部字节及CNN全部10个整数分数。结果输出预测、真实标签匹配与CNN耗时，并保存原始RX/TX、图片/张量及参考文件。预测错误保留`label_match=false`，不改标签、不当作协议失败或偷偷重试。工具遇首个异常停止且保留目录。

后续可省略`--full-source`快速采样：28个数据包，仍核RGB96及CNN全部分数，但**不证明源帧到PP映射**。每次仍须JTAG恢复，换新目录、递增`--sample`并按纸张填写真实`--label`；独立重新拍摄换`--session`。首轮每类3–5张只作探索，不作为正式准确率验收。单次应用退出后停住，下一次不能直接复用未恢复的Loader。

## 不开串口及只读复核

```powershell
python -X utf8 tools/cnn_handwritten_perf46/run.py --plan-only
python -X utf8 tools/cnn_handwritten_perf46/run.py --verify sim/cnn/board/handwritten_perf46_trial01_0_01
```

`--plan-only`检查固定软件及现行源码身份，不打开串口；正式采集还逐项核新ready封存。`--reset-method`仅接受`jtag`。复核使用日志内副本，不要求将现行源码切回旧版本。合成离线证据不能通过默认实板复核。

准备收据：`sim/cnn/handwritten_perf46_20261019_a/ready.json`。离线检查`checks_02/review.json`仅覆盖本次PC适配，复用原协议/数学/C控制证据，不是HDL、真实CPU、当前046相机/CNN实板或正式识别准确率PASS。`checks_01`保留首次辅助脚本子进程编码失败，未覆盖为成功记录。
