
`define CONTROLLER_PHY_MODE

`define AXI_REDUCED_EN

`define CS_N_EN
 
`define DQ0_EN
 
`define DQ1_EN
 
`define DQ2_EN
 
`define DQ3_EN

`define CKE_DQS_EN

`define CK_DQS_EN 

`define BA2_EN

`define A5_DQS_EN

`define A11_DQS_EN

`define A12_EN

`define A13_EN

`define A14_EN

`define A14_DQS_EN
