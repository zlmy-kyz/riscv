`timescale 1ns / 1ps

// SoC 顶层：CPU + 独立指令/数据总线 + ROM/RAM/MMIO，可选共享 DDR3。
module soc_top #(
    parameter [31:0] RESET_PC = 32'h0000_0000,
    parameter [31:0] INST_ROM_BASE = RESET_PC,
    // 默认让 RAM 跟随测试程序的链接基址；正式上板时可独立覆写。
    parameter [31:0] DATA_RAM_BASE = RESET_PC,
    parameter [31:0] MMIO_BASE = 32'h1000_0000,
    parameter integer ENABLE_CNN = 0,
    parameter integer ENABLE_PREPROCESS = 0,
    parameter integer ENABLE_CAMERA = 0,
    parameter integer ENABLE_DDR = 0,
    parameter [31:0] DDR_BASE = 32'h4000_0000,
    parameter [31:0] DDR_ADDR_MASK = 32'he000_0000,
    parameter integer DDR_MEM_DQ_WIDTH = 16,
    parameter integer DDR_POSTED_WRITE_ENABLE = 1,
    parameter integer INST_REQ_STALL_CYCLES = 0,
    parameter integer INST_RSP_DELAY_CYCLES = 0,
    parameter integer DATA_REQ_STALL_CYCLES = 0,
    parameter integer DATA_RSP_DELAY_CYCLES = 0,
    parameter [31:0] UART_BASE = 32'h1000_1000,
    parameter integer UART_CLK_HZ = 93_750_000,
    parameter integer UART_RSP_DELAY_CYCLES = 0,
    parameter integer PERF_ENABLE = 1,
    parameter integer PERF_AUTO_ARM = 1,
    parameter [31:0] PERF_START_PC = 32'h400007d0,
    parameter [31:0] PERF_STOP_PC = 32'h400007f4,
    // Camera builds keep registered load data; posted store ACKs may bypass it.
    parameter integer DDR_POSTED_STORE_ACK_BYPASS_ENABLE = 1,
    parameter integer PERF_DIAG_ENABLE = 1,
    parameter integer PERF_DETAIL_ENABLE = 1
) (
    output wire cnn_req_valid, cnn_req_write,
    output wire [1:0] cnn_req_size,
    output wire [31:0] cnn_req_addr, cnn_req_wdata,
    output wire [3:0] cnn_req_wstrb,
    input wire cnn_req_ready, cnn_rsp_valid, cnn_rsp_error,
    input wire [31:0] cnn_rsp_rdata,
    output wire pp_req_valid, pp_req_write,
    output wire [1:0] pp_req_size,
    output wire [31:0] pp_req_addr, pp_req_wdata,
    output wire [3:0] pp_req_wstrb,
    input wire pp_req_ready, pp_rsp_valid, pp_rsp_error,
    input wire [31:0] pp_rsp_rdata,
    input wire preprocess_busy, preprocess_done,
    output wire cam_req_valid, cam_req_write,
    output wire [1:0] cam_req_size,
    output wire [31:0] cam_req_addr, cam_req_wdata,
    output wire [3:0] cam_req_wstrb,
    input wire cam_req_ready, cam_rsp_valid, cam_rsp_error,
    input wire [31:0] cam_rsp_rdata,
    input wire camera_busy,
    input wire camera_dual_mode,
    input wire [1:0] camera_cpu_owned,
    input  wire        clk,
    input  wire        resetn,
    input  wire        irq_external,
    input  wire        irq_software,
    input  wire        irq_timer,
    output wire [31:0] debug_wb_pc,
    output wire [ 3:0] debug_wb_rf_we,
    output wire [ 4:0] debug_wb_rf_wnum,
    output wire [31:0] debug_wb_rf_wdata,
    output wire [31:0] debug_inst,

    // Pango DDR3 IP 的 core_clk 域用户口；ENABLE_DDR=0 时输出为 0。
    input  wire        ddr_init_done,
    output wire [27:0] ddr_axi_awaddr,
    output wire        ddr_axi_awuser_ap,
    output wire [ 3:0] ddr_axi_awuser_id,
    output wire [ 3:0] ddr_axi_awlen,
    input  wire        ddr_axi_awready,
    output wire        ddr_axi_awvalid,
    output wire [8*DDR_MEM_DQ_WIDTH-1:0] ddr_axi_wdata,
    output wire [DDR_MEM_DQ_WIDTH-1:0] ddr_axi_wstrb,
    input  wire        ddr_axi_wready,
    input  wire [ 3:0] ddr_axi_wusero_id,
    input  wire        ddr_axi_wusero_last,
    output wire [27:0] ddr_axi_araddr,
    output wire        ddr_axi_aruser_ap,
    output wire [ 3:0] ddr_axi_aruser_id,
    output wire [ 3:0] ddr_axi_arlen,
    input  wire        ddr_axi_arready,
    output wire        ddr_axi_arvalid,
    input  wire [8*DDR_MEM_DQ_WIDTH-1:0] ddr_axi_rdata,
    input  wire [ 3:0] ddr_axi_rid,
    input  wire        ddr_axi_rlast,
    input  wire        ddr_axi_rvalid,
    output wire [ 1:0] selftest_status,
    input  wire        uart_rx,
    output wire        uart_tx
);

    // CPU 使用字节地址；ROM/RAM IP 使用 32 位字地址。
    wire [7:0] perf_events;
    wire [31:0] perf_branch_target, perf_fetch_pc;
    wire [5:0] perf_cache_events;
    wire [1:0] perf_cache_enabled;
    wire [2:0] perf_wait_events;
    wire [15:0] perf_detail_cpu, perf_detail_bridge;
    wire [14:0] perf_diag_flags;
    wire [31:0] perf_diag_target_pc, perf_diag_pending_pc, perf_diag_buffer_pc;
    wire        inst_req_valid;
    wire [31:0] inst_req_addr;
    wire        inst_req_ready;
    wire        inst_rsp_valid;
    wire [31:0] inst_rsp_rdata;
    wire        inst_rsp_error;
    wire        rom_bus_req_valid;
    wire [31:0] rom_bus_req_addr;
    wire        rom_bus_req_ready;
    wire        rom_bus_rsp_valid;
    wire [31:0] rom_bus_rsp_rdata;
    wire        rom_bus_rsp_error;
    wire        inst_ddr_req_valid;
    wire [31:0] inst_ddr_req_addr;
    wire        inst_ddr_req_ready;
    wire        inst_ddr_rsp_valid;
    wire [31:0] inst_ddr_rsp_rdata;
    wire        inst_ddr_rsp_error;
    wire [11:0] inst_rom_addr;
    wire [31:0] inst_rom_rdata;
    wire        data_req_valid;
    wire        data_req_write;
    wire [ 1:0] data_req_size;
    wire [31:0] data_req_addr;
    wire [31:0] data_req_wdata;
    wire [ 3:0] data_req_wstrb;
    wire        data_req_ready;
    wire        data_rsp_valid;
    wire [31:0] data_rsp_rdata;
    wire        data_rsp_error;
    wire        uart_irq;
    // Preserve the existing generic external source; board_top ties it low.
    // UART is synchronous to this same core_clk domain and holds a level.
    wire        cpu_irq_external = irq_external | uart_irq;

    wire        ram_bus_req_valid;
    wire        ram_bus_req_write;
    wire [ 1:0] ram_bus_req_size;
    wire [31:0] ram_bus_req_addr;
    wire [31:0] ram_bus_req_wdata;
    wire [ 3:0] ram_bus_req_wstrb;
    wire        ram_bus_req_ready;
    wire        ram_bus_rsp_valid;
    wire [31:0] ram_bus_rsp_rdata;
    wire        ram_bus_rsp_error;

    wire        data_ddr_req_valid;
    wire        data_ddr_req_write;
    wire [ 1:0] data_ddr_req_size;
    wire [31:0] data_ddr_req_addr;
    wire [31:0] data_ddr_req_wdata;
    wire [ 3:0] data_ddr_req_wstrb;
    wire        data_ddr_req_ready;
    wire        data_ddr_rsp_valid;
    wire [31:0] data_ddr_rsp_rdata;
    wire        data_ddr_rsp_error;
    wire        ddr_write_buffer_busy;
    localparam integer DDR_WRITE_ORDER_ACTIVE = (ENABLE_DDR != 0) &&
                          (DDR_MEM_DQ_WIDTH == 32) && (DDR_POSTED_WRITE_ENABLE != 0);

    wire        mmio_req_valid;
    wire        mmio_req_write;
    wire [ 1:0] mmio_req_size;
    wire [31:0] mmio_req_addr;
    wire [31:0] mmio_req_wdata;
    wire [ 3:0] mmio_req_wstrb;
    wire        mmio_req_ready;
    wire        mmio_rsp_valid;
    wire [31:0] mmio_rsp_rdata;
    wire        mmio_rsp_error;

    wire uart_req_valid, uart_req_write, uart_req_ready;
    wire [1:0] uart_req_size;
    wire [31:0] uart_req_addr, uart_req_wdata, uart_rsp_rdata;
    wire [3:0] uart_req_wstrb;
    wire uart_rsp_valid, uart_rsp_error;

    wire [11:0] data_ram_addr;
    wire [31:0] data_ram_wdata;
    wire [31:0] data_ram_rdata;
    wire [ 3:0] data_ram_wstrb;
    wire        data_ram_we;

    // 兼容现有测试台的观察点：data_write 表示一次真正被接受的 store，
    // 因此即使总线反压也只产生一个周期的提交脉冲。
    wire [31:0] data_addr;
    wire [31:0] data_wdata;
    wire        data_read;
    wire        data_write;
    wire [31:0] inst_addr;
    assign inst_addr  = inst_req_addr;
    assign data_addr  = data_req_addr;
    assign data_wdata = data_req_wdata;
    assign data_read  = data_req_valid && data_req_ready && !data_req_write;
    assign data_write = data_req_valid && data_req_ready &&  data_req_write;

    mycpu_sync #(
        .RESET_PC(RESET_PC),
        .EXTERNAL_MEM_DRAIN_ENABLE(DDR_WRITE_ORDER_ACTIVE),
        .DIAG_PERF_ENABLE((PERF_ENABLE != 0) && (PERF_DIAG_ENABLE != 0)),
        .DETAIL_PERF_ENABLE((PERF_ENABLE != 0) && (PERF_DIAG_ENABLE != 0) && (PERF_DETAIL_ENABLE != 0))
    ) u_cpu (
        .clk               (clk),
        .resetn            (resetn),
        .irq_external      (cpu_irq_external),
        .irq_software      (irq_software),
        .irq_timer         (irq_timer),
        .memory_order_busy (ddr_write_buffer_busy),
        .inst_req_valid    (inst_req_valid),
        .inst_req_addr     (inst_req_addr),
        .inst_req_ready    (inst_req_ready),
        .inst_rsp_valid    (inst_rsp_valid),
        .inst_rsp_rdata    (inst_rsp_rdata),
        .inst_rsp_error    (inst_rsp_error),
        .data_req_valid    (data_req_valid),
        .data_req_write    (data_req_write),
        .data_req_size     (data_req_size),
        .data_req_addr     (data_req_addr),
        .data_req_wdata    (data_req_wdata),
        .data_req_wstrb    (data_req_wstrb),
        .data_req_ready    (data_req_ready),
        .data_rsp_valid    (data_rsp_valid),
        .data_rsp_rdata    (data_rsp_rdata),
        .data_rsp_error    (data_rsp_error),
        .debug_wb_pc       (debug_wb_pc),
        .debug_wb_rf_we    (debug_wb_rf_we),
        .debug_wb_rf_wnum  (debug_wb_rf_wnum),
        .debug_wb_rf_wdata (debug_wb_rf_wdata),
        .debug_inst        (debug_inst),
        .perf_events(perf_events), .perf_branch_target(perf_branch_target), .perf_fetch_pc(perf_fetch_pc),
        .perf_diag_flags(perf_diag_flags), .perf_diag_target_pc(perf_diag_target_pc),
        .perf_diag_pending_pc(perf_diag_pending_pc), .perf_diag_buffer_pc(perf_diag_buffer_pc),
        .perf_detail_cpu(perf_detail_cpu)
    );

    inst_bus_interconnect #(
        .ENABLE_PREPROCESS(ENABLE_PREPROCESS),
        .ENABLE_CAMERA (ENABLE_CAMERA),
        .ROM_BASE      (INST_ROM_BASE),
        .ROM_ADDR_MASK (32'hffff_c000),
        .ENABLE_DDR     (ENABLE_DDR),
        .DDR_BASE       (DDR_BASE),
        .DDR_ADDR_MASK  (DDR_ADDR_MASK)
    ) u_inst_bus_interconnect (
        .clk           (clk),
        .resetn        (resetn),
        .m_req_valid   (inst_req_valid),
        .m_req_addr    (inst_req_addr),
        .m_req_ready   (inst_req_ready),
        .m_rsp_valid   (inst_rsp_valid),
        .m_rsp_rdata   (inst_rsp_rdata),
        .m_rsp_error   (inst_rsp_error),
        .rom_req_valid (rom_bus_req_valid),
        .rom_req_addr  (rom_bus_req_addr),
        .rom_req_ready (rom_bus_req_ready),
        .rom_rsp_valid (rom_bus_rsp_valid),
        .rom_rsp_rdata (rom_bus_rsp_rdata),
        .rom_rsp_error (rom_bus_rsp_error),
        .ddr_req_valid (inst_ddr_req_valid),
        .ddr_req_addr  (inst_ddr_req_addr),
        .ddr_req_ready (inst_ddr_req_ready),
        .ddr_rsp_valid (inst_ddr_rsp_valid),
        .ddr_rsp_rdata (inst_ddr_rsp_rdata),
        .ddr_rsp_error (inst_ddr_rsp_error)
    );

    inst_bram_adapter #(
        .ROM_ADDR_WIDTH(12),
        .REQ_STALL_CYCLES(INST_REQ_STALL_CYCLES),
        .RSP_DELAY_CYCLES(INST_RSP_DELAY_CYCLES)
    ) u_inst_bram_adapter (
        .clk        (clk),
        .resetn     (resetn),
        .req_valid  (rom_bus_req_valid),
        .req_addr   (rom_bus_req_addr),
        .req_ready  (rom_bus_req_ready),
        .rsp_valid  (rom_bus_rsp_valid),
        .rsp_rdata  (rom_bus_rsp_rdata),
        .rsp_error  (rom_bus_rsp_error),
        .rom_addr   (inst_rom_addr),
        .rom_rdata  (inst_rom_rdata)
    );

    // 4096 x 32 bit = 16 KiB。适配器收到的已经是相对INST_ROM_BASE
    // 的局部字节地址，不再把窗口外高地址按低位镜像到ROM。
    inst_rom u_inst_rom (
        .addr    (inst_rom_addr),
        .clk     (clk),
        .rst     (!resetn),
        .rd_data (inst_rom_rdata)
    );

    data_bus_interconnect #(
        .ENABLE_CNN(ENABLE_CNN),
        .ENABLE_PREPROCESS(ENABLE_PREPROCESS),
        .ENABLE_CAMERA (ENABLE_CAMERA),
        .RAM_BASE      (DATA_RAM_BASE),
        .RAM_ADDR_MASK (32'hffff_c000),
        .MMIO_BASE     (MMIO_BASE),
        .MMIO_ADDR_MASK(32'hffff_f000),
        .ENABLE_DDR    (ENABLE_DDR),
        .DDR_BASE      (DDR_BASE),
        .DDR_ADDR_MASK (DDR_ADDR_MASK),
        .ENABLE_UART   (1),
        .UART_BASE     (UART_BASE),
        .DDR_WRITE_ORDER_ENABLE(DDR_WRITE_ORDER_ACTIVE)
    ) u_data_bus_interconnect (
        .cnn_req_valid(cnn_req_valid), .cnn_req_write(cnn_req_write),
        .cnn_req_size(cnn_req_size), .cnn_req_addr(cnn_req_addr),
        .cnn_req_wdata(cnn_req_wdata), .cnn_req_wstrb(cnn_req_wstrb),
        .cnn_req_ready(cnn_req_ready), .cnn_rsp_valid(cnn_rsp_valid),
        .cnn_rsp_error(cnn_rsp_error), .cnn_rsp_rdata(cnn_rsp_rdata),
        .pp_req_valid(pp_req_valid), .pp_req_write(pp_req_write),
        .pp_req_size(pp_req_size), .pp_req_addr(pp_req_addr),
        .pp_req_wdata(pp_req_wdata), .pp_req_wstrb(pp_req_wstrb),
        .pp_req_ready(pp_req_ready), .pp_rsp_valid(pp_rsp_valid),
        .pp_rsp_error(pp_rsp_error), .pp_rsp_rdata(pp_rsp_rdata),
        .preprocess_busy(preprocess_busy), .preprocess_done(preprocess_done),
        .cam_req_valid(cam_req_valid), .cam_req_write(cam_req_write),
        .cam_req_size(cam_req_size), .cam_req_addr(cam_req_addr),
        .cam_req_wdata(cam_req_wdata), .cam_req_wstrb(cam_req_wstrb),
        .cam_req_ready(cam_req_ready), .cam_rsp_valid(cam_rsp_valid),
        .cam_rsp_error(cam_rsp_error), .cam_rsp_rdata(cam_rsp_rdata),
        .camera_busy(camera_busy),
        .camera_dual_mode(camera_dual_mode), .camera_cpu_owned(camera_cpu_owned),

        .clk            (clk),
        .resetn         (resetn),
        .ddr_write_buffer_busy(ddr_write_buffer_busy),
        .m_req_valid    (data_req_valid),
        .m_req_write    (data_req_write),
        .m_req_size     (data_req_size),
        .m_req_addr     (data_req_addr),
        .m_req_wdata    (data_req_wdata),
        .m_req_wstrb    (data_req_wstrb),
        .m_req_ready    (data_req_ready),
        .m_rsp_valid    (data_rsp_valid),
        .m_rsp_rdata    (data_rsp_rdata),
        .m_rsp_error    (data_rsp_error),
        .ram_req_valid  (ram_bus_req_valid),
        .ram_req_write  (ram_bus_req_write),
        .ram_req_size   (ram_bus_req_size),
        .ram_req_addr   (ram_bus_req_addr),
        .ram_req_wdata  (ram_bus_req_wdata),
        .ram_req_wstrb  (ram_bus_req_wstrb),
        .ram_req_ready  (ram_bus_req_ready),
        .ram_rsp_valid  (ram_bus_rsp_valid),
        .ram_rsp_rdata  (ram_bus_rsp_rdata),
        .ram_rsp_error  (ram_bus_rsp_error),
        .mmio_req_valid (mmio_req_valid),
        .mmio_req_write (mmio_req_write),
        .mmio_req_size  (mmio_req_size),
        .mmio_req_addr  (mmio_req_addr),
        .mmio_req_wdata (mmio_req_wdata),
        .mmio_req_wstrb (mmio_req_wstrb),
        .mmio_req_ready (mmio_req_ready),
        .mmio_rsp_valid (mmio_rsp_valid),
        .mmio_rsp_rdata (mmio_rsp_rdata),
        .mmio_rsp_error (mmio_rsp_error),
        .ddr_req_valid  (data_ddr_req_valid),
        .ddr_req_write  (data_ddr_req_write),
        .ddr_req_size   (data_ddr_req_size),
        .ddr_req_addr   (data_ddr_req_addr),
        .ddr_req_wdata  (data_ddr_req_wdata),
        .ddr_req_wstrb  (data_ddr_req_wstrb),
        .ddr_req_ready  (data_ddr_req_ready),
        .ddr_rsp_valid  (data_ddr_rsp_valid),
        .ddr_rsp_rdata  (data_ddr_rsp_rdata),
        .ddr_rsp_error  (data_ddr_rsp_error),
        .uart_req_valid(uart_req_valid), .uart_req_write(uart_req_write),
        .uart_req_size(uart_req_size), .uart_req_addr(uart_req_addr),
        .uart_req_wdata(uart_req_wdata), .uart_req_wstrb(uart_req_wstrb),
        .uart_req_ready(uart_req_ready), .uart_rsp_valid(uart_rsp_valid),
        .uart_rsp_rdata(uart_rsp_rdata), .uart_rsp_error(uart_rsp_error)
    );

    // CNN integration increases placement pressure. Break the synchronous RAM
    // QA -> response mux -> load forwarding -> branch -> instruction ROM path.
    // Delay the ENTIRE response (including store acknowledgements) one cycle;
    // the interconnect retains its owner until this registered response arrives.
    wire ram_raw_rsp_valid, ram_raw_rsp_error;
    wire [31:0] ram_raw_rsp_rdata;
    generate if (ENABLE_CNN != 0) begin : g_cnn_ram_rsp_register
        (* syn_preserve=1 *) reg valid_q;
        (* syn_preserve=1 *) reg [31:0] data_q;
        reg error_q;
        always @(posedge clk) begin
            if (!resetn) begin valid_q<=0; data_q<=0; error_q<=0; end
            else begin
                valid_q<=ram_raw_rsp_valid;
                if (ram_raw_rsp_valid) begin
                    data_q<=ram_raw_rsp_rdata;
                    error_q<=ram_raw_rsp_error;
                end
            end
        end
        assign ram_bus_rsp_valid=valid_q;
        assign ram_bus_rsp_rdata=data_q;
        assign ram_bus_rsp_error=error_q;
    end else begin : g_direct_ram_rsp
        assign ram_bus_rsp_valid=ram_raw_rsp_valid;
        assign ram_bus_rsp_rdata=ram_raw_rsp_rdata;
        assign ram_bus_rsp_error=ram_raw_rsp_error;
    end endgenerate

    data_bram_adapter #(
        .RAM_ADDR_WIDTH(12),
        .REQ_STALL_CYCLES(DATA_REQ_STALL_CYCLES),
        .RSP_DELAY_CYCLES(DATA_RSP_DELAY_CYCLES)
    ) u_data_bram_adapter (
        .clk        (clk),
        .resetn     (resetn),
        .req_valid  (ram_bus_req_valid),
        .req_write  (ram_bus_req_write),
        .req_size   (ram_bus_req_size),
        .req_addr   (ram_bus_req_addr),
        .req_wdata  (ram_bus_req_wdata),
        .req_wstrb  (ram_bus_req_wstrb),
        .req_ready  (ram_bus_req_ready),
        .rsp_valid  (ram_raw_rsp_valid),
        .rsp_rdata  (ram_raw_rsp_rdata),
        .rsp_error  (ram_raw_rsp_error),
        .ram_addr   (data_ram_addr),
        .ram_wdata  (data_ram_wdata),
        .ram_wstrb  (data_ram_wstrb),
        .ram_we     (data_ram_we),
        .ram_rdata  (data_ram_rdata)
    );

    data_ram u_data_ram (
        .wr_data    (data_ram_wdata),
        .addr       (data_ram_addr),
        .wr_en      (data_ram_we),
        .wr_byte_en (data_ram_wstrb),
        .clk        (clk),
        .rst        (!resetn),
        .rd_data    (data_ram_rdata)
    );

    simple_mmio #(.PERF_ENABLE(PERF_ENABLE),
        .DETAIL_PERF_ENABLE((PERF_ENABLE != 0) && (PERF_DIAG_ENABLE != 0) && (PERF_DETAIL_ENABLE != 0)),
        .DIAG_PERF_ENABLE((PERF_ENABLE != 0) && (PERF_DIAG_ENABLE != 0)),
        .DIAG_DDR_ENABLE(ENABLE_DDR),
        .CACHE_PERF_ENABLE((PERF_ENABLE != 0) && (ENABLE_DDR != 0)), .PERF_AUTO_ARM(PERF_AUTO_ARM),
        .PERF_START_PC(PERF_START_PC), .PERF_STOP_PC(PERF_STOP_PC)) u_simple_mmio (
        .clk       (clk),
        .resetn    (resetn),
        .req_valid (mmio_req_valid),
        .req_write (mmio_req_write),
        .req_size  (mmio_req_size),
        .req_addr  (mmio_req_addr),
        .req_wdata (mmio_req_wdata),
        .req_wstrb (mmio_req_wstrb),
        .req_ready (mmio_req_ready),
        .rsp_valid (mmio_rsp_valid),
        .rsp_rdata (mmio_rsp_rdata),
        .rsp_error (mmio_rsp_error),
        .test_status(selftest_status),
        .perf_events(perf_events), .perf_retire_pc(debug_wb_pc),
        .perf_branch_target(perf_branch_target), .perf_fetch_pc(perf_fetch_pc),
        .perf_ar_fire(ddr_axi_arvalid && ddr_axi_arready),
        .perf_aw_fire(ddr_axi_awvalid && ddr_axi_awready),
        .perf_cache_events(perf_cache_events), .perf_cache_enabled(perf_cache_enabled),
        .perf_wait_events(perf_wait_events), .perf_diag_flags(perf_diag_flags),
        .perf_diag_target_pc(perf_diag_target_pc), .perf_diag_pending_pc(perf_diag_pending_pc),
        .perf_diag_buffer_pc(perf_diag_buffer_pc),
        .perf_detail_cpu(perf_detail_cpu), .perf_detail_bridge(perf_detail_bridge)
    );

    uart_mmio #(.CLK_HZ(UART_CLK_HZ), .RSP_DELAY_CYCLES(UART_RSP_DELAY_CYCLES)) u_uart_mmio (
        .clk(clk), .resetn(resetn), .req_valid(uart_req_valid),
        .req_write(uart_req_write), .req_size(uart_req_size),
        .req_addr(uart_req_addr), .req_wdata(uart_req_wdata), .req_wstrb(uart_req_wstrb),
        .req_ready(uart_req_ready), .rsp_valid(uart_rsp_valid),
        .rsp_rdata(uart_rsp_rdata), .rsp_error(uart_rsp_error),
        .uart_rx(uart_rx), .uart_tx(uart_tx), .uart_irq(uart_irq)
    );

    generate
        if (ENABLE_DDR != 0) begin : g_ddr
            wire bridge_data_rsp_valid, bridge_data_rsp_error;
            wire [31:0] bridge_data_rsp_rdata;
            if (ENABLE_CAMERA != 0) begin : g_camera_data_rsp_register
                // Keep the D-cache DRM -> load forwarding -> ID branch -> I-ROM
                // timing cut. Only posted store ACKs, which carry no load data,
                // bypass this stage. Their order still comes from the write buffer.
                // Latch the type at the BRIDGE acceptance edge: live req_write
                // may already describe a younger load when the old ACK arrives.
                localparam integer FAST_STORE_ACK_ACTIVE = DDR_WRITE_ORDER_ACTIVE &&
                                              (DDR_POSTED_STORE_ACK_BYPASS_ENABLE != 0);
                reg response_is_posted_store_q;
                wire fast_store_ack = response_is_posted_store_q && bridge_data_rsp_valid;
                wire accept_fast_store = FAST_STORE_ACK_ACTIVE &&
                                          data_ddr_req_valid && data_ddr_req_ready && data_ddr_req_write;
                always @(posedge clk) begin
                    if (!resetn)
                        response_is_posted_store_q <= 1'b0;
                    else if (data_ddr_req_valid && data_ddr_req_ready)
                        response_is_posted_store_q <= FAST_STORE_ACK_ACTIVE && data_ddr_req_write;
                end

                // The upstream interconnect has one outstanding request and
                // retains its owner until the selected response is consumed.
                // A delayed load response cannot overlap a younger store ACK:
                // that store is accepted no earlier than the load consumption
                // edge, and the bridge responds at least one edge after acceptance.
                (* syn_preserve=1 *) reg valid_q;
                (* syn_preserve=1 *) reg [31:0] data_q;
                reg error_q;
                always @(posedge clk) begin
                    if (!resetn) begin
                        valid_q <= 1'b0;
                        data_q <= 32'b0;
                        error_q <= 1'b0;
                    end else begin
                        // A fast ACK must never reappear as a delayed response.
                        valid_q <= bridge_data_rsp_valid && !response_is_posted_store_q;
                        // Prepare the zero store payload at acceptance, not via
                        // a mux after data_q on the load-forwarding/branch path.
                        // On load-response/store-accept turnover, the consumer
                        // samples OLD data_q at this edge before it becomes zero.
                        // Single-outstanding ownership forbids a younger store
                        // acceptance while an older raw load awaits this register.
                        if (accept_fast_store)
                            data_q <= 32'b0;
                        else if (bridge_data_rsp_valid && !response_is_posted_store_q)
                            data_q <= bridge_data_rsp_rdata;
                        if (bridge_data_rsp_valid && !response_is_posted_store_q) begin
                            error_q <= bridge_data_rsp_error;
                        end
                    end
                end
                assign data_ddr_rsp_valid = valid_q || fast_store_ack;
                // Data is always registered, including the zero fast-store ACK.
                // The response owner only selects valid/error, never rdata.
                assign data_ddr_rsp_rdata = data_q;
                assign data_ddr_rsp_error = response_is_posted_store_q ? bridge_data_rsp_error : error_q;
            end else begin : g_direct_data_rsp
                assign data_ddr_rsp_valid = bridge_data_rsp_valid;
                assign data_ddr_rsp_rdata = bridge_data_rsp_rdata;
                assign data_ddr_rsp_error = bridge_data_rsp_error;
            end
            dual_sram_to_pango_ddr_bridge #(
                .PREPROCESS_UNCACHED_ENABLE(ENABLE_PREPROCESS),
                .CAMERA_UNCACHED_ENABLE(ENABLE_CAMERA),
                .MEM_DQ_WIDTH(DDR_MEM_DQ_WIDTH),
                .POSTED_WRITE_ENABLE(DDR_WRITE_ORDER_ACTIVE),
                .CACHE_PERF_ENABLE(PERF_ENABLE),
                .DETAIL_PERF_ENABLE((PERF_ENABLE != 0) && (PERF_DIAG_ENABLE != 0) && (PERF_DETAIL_ENABLE != 0)),
                .DIAG_PERF_ENABLE((PERF_ENABLE != 0) && (PERF_DIAG_ENABLE != 0))
            ) u_ddr_bridge (
                .clk              (clk),
                .resetn           (resetn),
                .ddr_init_done    (ddr_init_done),
                .write_buffer_busy(ddr_write_buffer_busy),
                .perf_cache_events(perf_cache_events),
                .perf_cache_enabled(perf_cache_enabled),
                .perf_wait_events(perf_wait_events),
                .perf_detail_bridge(perf_detail_bridge),
                .inst_req_valid   (inst_ddr_req_valid),
                .inst_req_addr    (inst_ddr_req_addr),
                .inst_req_ready   (inst_ddr_req_ready),
                .inst_rsp_valid   (inst_ddr_rsp_valid),
                .inst_rsp_rdata   (inst_ddr_rsp_rdata),
                .inst_rsp_error   (inst_ddr_rsp_error),
                .data_req_valid   (data_ddr_req_valid),
                .data_req_write   (data_ddr_req_write),
                .data_req_size    (data_ddr_req_size),
                .data_req_addr    (data_ddr_req_addr),
                .data_req_wdata   (data_ddr_req_wdata),
                .data_req_wstrb   (data_ddr_req_wstrb),
                .data_req_ready   (data_ddr_req_ready),
                .data_rsp_valid   (bridge_data_rsp_valid),
                .data_rsp_rdata   (bridge_data_rsp_rdata),
                .data_rsp_error   (bridge_data_rsp_error),
                .axi_awaddr       (ddr_axi_awaddr),
                .axi_awuser_ap    (ddr_axi_awuser_ap),
                .axi_awuser_id    (ddr_axi_awuser_id),
                .axi_awlen        (ddr_axi_awlen),
                .axi_awready      (ddr_axi_awready),
                .axi_awvalid      (ddr_axi_awvalid),
                .axi_wdata        (ddr_axi_wdata),
                .axi_wstrb        (ddr_axi_wstrb),
                .axi_wready       (ddr_axi_wready),
                .axi_wusero_id    (ddr_axi_wusero_id),
                .axi_wusero_last  (ddr_axi_wusero_last),
                .axi_araddr       (ddr_axi_araddr),
                .axi_aruser_ap    (ddr_axi_aruser_ap),
                .axi_aruser_id    (ddr_axi_aruser_id),
                .axi_arlen        (ddr_axi_arlen),
                .axi_arready      (ddr_axi_arready),
                .axi_arvalid      (ddr_axi_arvalid),
                .axi_rdata        (ddr_axi_rdata),
                .axi_rid          (ddr_axi_rid),
                .axi_rlast        (ddr_axi_rlast),
                .axi_rvalid       (ddr_axi_rvalid)
            );
        end else begin : g_no_ddr
            assign perf_detail_bridge = 16'b0;
            assign perf_cache_events = 6'b0;
            assign perf_cache_enabled = 2'b0;
            assign perf_wait_events = 3'b0;
            assign ddr_write_buffer_busy = 1'b0;
            assign inst_ddr_req_ready = 1'b0;
            assign inst_ddr_rsp_valid = 1'b0;
            assign inst_ddr_rsp_rdata = 32'b0;
            assign inst_ddr_rsp_error = 1'b0;
            assign data_ddr_req_ready = 1'b0;
            assign data_ddr_rsp_valid = 1'b0;
            assign data_ddr_rsp_rdata = 32'b0;
            assign data_ddr_rsp_error = 1'b0;
            assign ddr_axi_awaddr     = 28'b0;
            assign ddr_axi_awuser_ap  = 1'b0;
            assign ddr_axi_awuser_id  = 4'b0;
            assign ddr_axi_awlen      = 4'b0;
            assign ddr_axi_awvalid    = 1'b0;
            assign ddr_axi_wdata      = {(8*DDR_MEM_DQ_WIDTH){1'b0}};
            assign ddr_axi_wstrb      = {DDR_MEM_DQ_WIDTH{1'b0}};
            assign ddr_axi_araddr     = 28'b0;
            assign ddr_axi_aruser_ap  = 1'b0;
            assign ddr_axi_aruser_id  = 4'b0;
            assign ddr_axi_arlen      = 4'b0;
            assign ddr_axi_arvalid    = 1'b0;
        end
    endgenerate

endmodule
